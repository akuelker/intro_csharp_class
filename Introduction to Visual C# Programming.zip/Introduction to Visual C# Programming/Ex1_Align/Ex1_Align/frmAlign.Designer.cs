﻿namespace Ex1_Align
{
    partial class frmAlign
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAlign = new System.Windows.Forms.Label();
            this.btnQuit = new System.Windows.Forms.Button();
            this.cboAlign = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblAlign
            // 
            this.lblAlign.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAlign.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlign.Location = new System.Drawing.Point(12, 9);
            this.lblAlign.Name = "lblAlign";
            this.lblAlign.Size = new System.Drawing.Size(506, 60);
            this.lblAlign.TabIndex = 0;
            this.lblAlign.Text = "LEFT";
            this.lblAlign.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(428, 126);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(90, 38);
            this.btnQuit.TabIndex = 4;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // cboAlign
            // 
            this.cboAlign.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAlign.FormattingEnabled = true;
            this.cboAlign.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cboAlign.Location = new System.Drawing.Point(42, 113);
            this.cboAlign.Name = "cboAlign";
            this.cboAlign.Size = new System.Drawing.Size(315, 21);
            this.cboAlign.TabIndex = 5;
            this.cboAlign.SelectedIndexChanged += new System.EventHandler(this.cboAlign_SelectedIndexChanged);
            // 
            // frmAlign
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(530, 172);
            this.Controls.Add(this.cboAlign);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.lblAlign);
            this.Name = "frmAlign";
            this.Text = "Alignment";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblAlign;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.ComboBox cboAlign;
    }
}

