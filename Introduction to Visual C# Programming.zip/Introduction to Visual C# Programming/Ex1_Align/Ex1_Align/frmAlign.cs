﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex1_Align
{
    public partial class frmAlign : Form
    {
        public frmAlign()
        {
            InitializeComponent();
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {
        }

        private void btnCenter_Click(object sender, EventArgs e)
        {

        }

        private void btnRight_Click(object sender, EventArgs e)
        {

        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void cboAlign_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cboAlign.SelectedIndex)
            {
                case 0:
                    lblAlign.Text = "LEFT";
                    lblAlign.TextAlign = ContentAlignment.MiddleLeft;
                    break;
                case 1:
            lblAlign.Text = "CENTER";
            lblAlign.TextAlign = ContentAlignment.MiddleCenter;
            break;
                case 2:
            lblAlign.Text = "RIGHT";
            lblAlign.TextAlign = ContentAlignment.MiddleRight;
                    break;




            }


        }
    }
}
