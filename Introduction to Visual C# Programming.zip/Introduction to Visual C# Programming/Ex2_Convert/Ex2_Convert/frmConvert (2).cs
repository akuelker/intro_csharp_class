﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex2_Convert
{
    public partial class frmConvert : Form
    {
        public frmConvert()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            double dblConvert = double.Parse(txtConvert.Text);
            double dblConverted = 0;

            switch (cboConvert.SelectedIndex)
            {
                case 0:
                    dblConverted = 5.0 / 9.0 * (dblConvert - 32);
                    break;
                case 1:
                    dblConverted = 9.0 / 5.0 * dblConvert + 32;
                    break;
            }


            txtConverted.Text = dblConverted.ToString("n1"); 
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtConverted.Clear();
            txtConvert.Clear();
            txtConvert.Focus();
        }

        private void frmConvert_Load(object sender, EventArgs e)
        {
            cboConvert.SelectedIndex = 0;
        }

        private void cboConvert_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cboConvert.SelectedIndex)
            {
                case 0:
                    lblConverted.Text = "degrees Celsius";
                    break;
                case 1:
                    lblConverted.Text = "degrees Fahrenheit";
                    break;
            }
        }
    }
}
