﻿namespace Ex2_Convert
{
    partial class frmConvert
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtConverted = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtConvert = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnConvert = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblDeg = new System.Windows.Forms.Label();
            this.cboDeg = new System.Windows.Forms.ComboBox();
            this.lblUnits = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtConverted
            // 
            this.txtConverted.Location = new System.Drawing.Point(118, 68);
            this.txtConverted.Name = "txtConverted";
            this.txtConverted.ReadOnly = true;
            this.txtConverted.Size = new System.Drawing.Size(82, 20);
            this.txtConverted.TabIndex = 8;
            this.txtConverted.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Converted Temp:";
            // 
            // txtConvert
            // 
            this.txtConvert.Location = new System.Drawing.Point(118, 23);
            this.txtConvert.Name = "txtConvert";
            this.txtConvert.Size = new System.Drawing.Size(82, 20);
            this.txtConvert.TabIndex = 7;
            this.txtConvert.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Temp to Convert:";
            // 
            // btnConvert
            // 
            this.btnConvert.Location = new System.Drawing.Point(42, 112);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(60, 36);
            this.btnConvert.TabIndex = 11;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // btnClear
            // 
            this.btnClear.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClear.Location = new System.Drawing.Point(243, 112);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(60, 36);
            this.btnClear.TabIndex = 12;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblDeg
            // 
            this.lblDeg.AutoSize = true;
            this.lblDeg.Location = new System.Drawing.Point(227, 74);
            this.lblDeg.Name = "lblDeg";
            this.lblDeg.Size = new System.Drawing.Size(0, 13);
            this.lblDeg.TabIndex = 13;
            // 
            // cboDeg
            // 
            this.cboDeg.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDeg.FormattingEnabled = true;
            this.cboDeg.Items.AddRange(new object[] {
            "degrees Fahrenheit",
            "degrees Celsius"});
            this.cboDeg.Location = new System.Drawing.Point(230, 23);
            this.cboDeg.Name = "cboDeg";
            this.cboDeg.Size = new System.Drawing.Size(121, 21);
            this.cboDeg.TabIndex = 14;
            // 
            // lblUnits
            // 
            this.lblUnits.AutoSize = true;
            this.lblUnits.Location = new System.Drawing.Point(240, 71);
            this.lblUnits.Name = "lblUnits";
            this.lblUnits.Size = new System.Drawing.Size(0, 13);
            this.lblUnits.TabIndex = 15;
            // 
            // frmConvert
            // 
            this.AcceptButton = this.btnConvert;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClear;
            this.ClientSize = new System.Drawing.Size(366, 160);
            this.Controls.Add(this.lblUnits);
            this.Controls.Add(this.cboDeg);
            this.Controls.Add(this.lblDeg);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.txtConverted);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtConvert);
            this.Controls.Add(this.label1);
            this.Name = "frmConvert";
            this.Text = "Temp Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtConverted;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtConvert;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblDeg;
        private System.Windows.Forms.ComboBox cboDeg;
        private System.Windows.Forms.Label lblUnits;
    }
}

