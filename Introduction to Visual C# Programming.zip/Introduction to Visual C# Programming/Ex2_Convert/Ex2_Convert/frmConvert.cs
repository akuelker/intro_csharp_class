﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex2_Convert
{
    public partial class frmConvert : Form
    {
        public frmConvert()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            double dblConvert = double.Parse(txtConvert.Text);

            switch (cboDeg.SelectedIndex)
            {
                case 0:

            double dblConverted = 5.0 / 9.0 * (dblConvert - 32);
            txtConverted.Text = dblConverted.ToString("n1");
            lblUnits.Text = "degrees Celsius";
            break;
                case 1:
            
            double dblConverted2 = 9.0 / 5.0 * (dblConvert + 32);
            txtConverted.Text = dblConverted2.ToString("n1");
            lblUnits.Text = "degrees Fahrenheit";
            break;


        }
        }
        


        private void btnClear_Click(object sender, EventArgs e)
        {
            txtConverted.Clear();
            txtConvert.Clear();
            txtConvert.Focus();
        }
    }
}
