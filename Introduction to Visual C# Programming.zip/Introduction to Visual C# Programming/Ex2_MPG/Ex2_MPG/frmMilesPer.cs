﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex2_MPG
{
    public partial class frmMilesPer : Form
    {
        public frmMilesPer()
        {
            InitializeComponent();
        }

        private void btnCompute_Click(object sender, EventArgs e)
        {
            double dblMPG = 
             (double.Parse(txtEnd.Text) - 
                    double.Parse(txtStart.Text)) / 
                                double.Parse(txtGallons.Text);
            //output
            txtMPG.Text = dblMPG.ToString("n1");
        }
    }
}
