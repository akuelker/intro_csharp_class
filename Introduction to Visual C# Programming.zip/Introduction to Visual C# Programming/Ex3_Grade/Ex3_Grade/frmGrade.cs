﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex3_Grade
{
    public partial class frmGrade : Form
    {
        public frmGrade()
        {
            InitializeComponent();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            try
            {
                lblGrade.Text = "";
                int intScore = int.Parse(txtScore.Text);
                String strGrade = "";
                if (intScore >= 0 && intScore <= 100)
                {
                    if (intScore >= 90)
                        strGrade = "A";
                    else if (intScore >= 80)
                        strGrade = "B";
                    else if (intScore >= 70)
                        strGrade = "C";
                    else if (intScore >= 60)
                        strGrade = "D";
                    else
                        strGrade = "F";

                    lblGrade.Text = strGrade;
                }
                else
                {
                   throw new Exception(); // send to catch!
                }
            }
            catch
            {
                DialogResult result =
                    MessageBox.Show("Enter valid numbers between 0 and 100\nTry Again?",
                        "Data Entry Error",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Error);

                if (result == DialogResult.No)
                    Close();
                else
                {
                    txtScore.SelectAll();
                    txtScore.Focus();
                    
                }

            }
        }
    }
}
