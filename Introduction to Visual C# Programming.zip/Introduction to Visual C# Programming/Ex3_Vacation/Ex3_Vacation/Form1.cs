﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex3_Vacation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVote_Click(object sender, EventArgs e)
        {
            int intYears = int.Parse(txtYears.Text);
            int intDays = 0;

            if (intYears >= 11)
                intDays = 20;
            else if (intYears >= 6)
                intDays = 15;
            else if (intYears >= 1)
                intDays = 10;
            else
                intDays = 5;

            MessageBox.Show("You get " + intDays + " days of vacation.");
        }
    }
}
