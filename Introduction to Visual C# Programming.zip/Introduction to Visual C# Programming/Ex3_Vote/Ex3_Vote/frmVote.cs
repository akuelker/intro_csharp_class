﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex3_Vote
{
    public partial class frmVote : Form
    {
        public frmVote()
        {
            InitializeComponent();
        }

        private void btnVote_Click(object sender, EventArgs e)
        {
            int intAge = int.Parse(txtAge.Text);

            if (intAge >= 18)
                MessageBox.Show("you can vote!");
            else
            {
                MessageBox.Show("Wait " + (18 - intAge) + 
                            " more years.");
            }
        }
    }
}
