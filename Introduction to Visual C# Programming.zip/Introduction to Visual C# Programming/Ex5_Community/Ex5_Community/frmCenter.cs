﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex5_Community
{
    public partial class frmCenter : Form
    {
        public frmCenter()
        {
            InitializeComponent();
        }

        private void btnDues_Click(object sender, EventArgs e)
        {
            String strCity = cboCity.Text;

            double dblDues = 100;
            double dblDisc = 0;

            switch (strCity.ToLower())
            {
                case "kirkwood":
                case "chesterfield":
                    dblDisc = dblDues * .05;
                    dblDues *= .95;
                    break;
                case "clayton":
                case "des peres":
                    dblDisc = dblDues * .10;
                    dblDues *= .90;
                    break;
                case "webster groves":
                case "maplewood":
                    dblDisc = dblDues * .20;
                    dblDues *= .80;
                    break;
            }

            txtReg.Text = (100).ToString("C");
            txtDisc.Text = dblDisc.ToString("C");
            txtTotal.Text = dblDues.ToString("C");

        }
    }
}
