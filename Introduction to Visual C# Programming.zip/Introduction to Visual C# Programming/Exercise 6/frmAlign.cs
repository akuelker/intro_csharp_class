﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex1_Align
{
    public partial class frmAlign : Form
    {
        public frmAlign()
        {
            InitializeComponent();
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {
        }

        private void btnCenter_Click(object sender, EventArgs e)
        {

        }

        private void btnRight_Click(object sender, EventArgs e)
        {

        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void cboAlign_SelectedIndexChanged(object sender, EventArgs e)
        {

            }

        private void radLeft_CheckedChanged(object sender, EventArgs e)
        {

            lblAlign.TextAlign = ContentAlignment.MiddleLeft;
            lblAlign.Text = "LEFT";
        }

        private void radCenter_CheckedChanged(object sender, EventArgs e)
        {
            lblAlign.TextAlign = ContentAlignment.MiddleCenter;
            lblAlign.Text = "CENTER";
        }

        private void radRight_CheckedChanged(object sender, EventArgs e)
        {
            lblAlign.TextAlign = ContentAlignment.MiddleRight;
            lblAlign.Text = "RIGHT";
        }


        }


    }



