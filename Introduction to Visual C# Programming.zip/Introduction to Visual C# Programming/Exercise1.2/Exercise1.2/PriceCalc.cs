﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Exercise1._2
{
    public partial class PriceCalc : Form
    {
        public PriceCalc()
        {
            InitializeComponent();
        }

        private void lblTotal_Click(object sender, EventArgs e)
        {

        }

        private void lblDiscount_Click(object sender, EventArgs e)
        {

        }

        private void lblPrice_Click(object sender, EventArgs e)
        {

        }

        private void lblQuantity_Click(object sender, EventArgs e)
        {

        }

        private void PriceCalc_Load(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {

            try
            {



                //inputs

                int intQty = int.Parse(txtQuantity.Text);
                double dblPrice = double.Parse(txtPrice.Text);


                //process

                const double TAX_RATE = .05; //cannot change later programmatically, will get an error

                double dblSubTotal = intQty * dblPrice;
                double dblDiscountPercent = 0;
                double dblDiscountDollars = 0;


                if (intQty >= 30) //must be in parentheses when setting conditions
                    // { not needed because only executing one line
                    dblDiscountPercent = .40;
                else if (intQty >= 20)
                    dblDiscountPercent = .25;
                else if (intQty >= 10)
                    dblDiscountPercent = .10;
                else
                    dblDiscountPercent = 0;

                // }


                //can also do if, else but not necessary bc initialized to 0

                dblDiscountDollars = dblSubTotal * dblDiscountPercent;
                dblSubTotal -= dblDiscountDollars; //-= assignment operators, shortcut for saying this is equal to subtotal minus discount dollars

                dblSubTotal *= (1 + TAX_RATE); //assignment operator, now subtotal includes tax rate


                //outputs

                txtDiscount.Text = dblDiscountDollars.ToString("C");
                txtTotal.Text = dblSubTotal.ToString("C");//must convert BACK to string. can add format specifiers. "C"

            }

            catch (Exception ex) //anything that doesn't go correctly, will go here
                // /n character turn for new line
            {
                DialogResult result = //yes or no, one big statement
                MessageBox.Show("Please enter valid numbers.\nWould you like to try again?", "Data Entry Error", MessageBoxButtons.YesNo, MessageBoxIcon.Error);

                if (result == DialogResult.No)
                    this.Close();
                else
                {
                    txtQuantity.Clear();
                    txtPrice.Clear();
                    txtQuantity.Focus();
                }
            }
        }
    }
}
