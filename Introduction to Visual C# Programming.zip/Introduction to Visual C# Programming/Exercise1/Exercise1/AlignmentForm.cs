﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Exercise1
{
    public partial class AlignmentForm : Form
    {
        public AlignmentForm()
        {
            InitializeComponent();
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "Left";
            lblMessage.TextAlign = ContentAlignment.MiddleLeft;
            btnLeft.Enabled = false;
            btnRight.Enabled = true;
            btnCenter.Enabled = true;
        }

        private void btnCenter_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "Center";
            lblMessage.TextAlign = ContentAlignment.MiddleCenter;
            btnCenter.Enabled = false;
            btnLeft.Enabled = true;
            btnRight.Enabled = true;
        }

        private void btnRight_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "Right";
            lblMessage.TextAlign = ContentAlignment.MiddleRight;
            btnRight.Enabled = false;
            btnLeft.Enabled = true;
            btnCenter.Enabled = true;
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
           Close();
        }
    }
}
