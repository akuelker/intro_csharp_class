﻿namespace Exercise2._2
{
    partial class MPG
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtOdBeg = new System.Windows.Forms.TextBox();
            this.lblOdBeg = new System.Windows.Forms.Label();
            this.lblOdEnd = new System.Windows.Forms.Label();
            this.txtOdEnd = new System.Windows.Forms.TextBox();
            this.lblGas = new System.Windows.Forms.Label();
            this.txtGas = new System.Windows.Forms.TextBox();
            this.lblMPG = new System.Windows.Forms.Label();
            this.txtMPG = new System.Windows.Forms.TextBox();
            this.btnCompute = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtOdBeg
            // 
            this.txtOdBeg.Location = new System.Drawing.Point(146, 31);
            this.txtOdBeg.Name = "txtOdBeg";
            this.txtOdBeg.Size = new System.Drawing.Size(100, 20);
            this.txtOdBeg.TabIndex = 0;
            // 
            // lblOdBeg
            // 
            this.lblOdBeg.Location = new System.Drawing.Point(35, 31);
            this.lblOdBeg.Name = "lblOdBeg";
            this.lblOdBeg.Size = new System.Drawing.Size(110, 42);
            this.lblOdBeg.TabIndex = 1;
            this.lblOdBeg.Text = "Odometer Reading (Start of trip)";
            this.lblOdBeg.Click += new System.EventHandler(this.lblOdBeg_Click);
            // 
            // lblOdEnd
            // 
            this.lblOdEnd.Location = new System.Drawing.Point(37, 73);
            this.lblOdEnd.Name = "lblOdEnd";
            this.lblOdEnd.Size = new System.Drawing.Size(107, 42);
            this.lblOdEnd.TabIndex = 3;
            this.lblOdEnd.Text = "Odometer Reading (End of trip)";
            // 
            // txtOdEnd
            // 
            this.txtOdEnd.Location = new System.Drawing.Point(146, 73);
            this.txtOdEnd.Name = "txtOdEnd";
            this.txtOdEnd.Size = new System.Drawing.Size(100, 20);
            this.txtOdEnd.TabIndex = 2;
            // 
            // lblGas
            // 
            this.lblGas.AutoSize = true;
            this.lblGas.Location = new System.Drawing.Point(37, 115);
            this.lblGas.Name = "lblGas";
            this.lblGas.Size = new System.Drawing.Size(91, 13);
            this.lblGas.TabIndex = 5;
            this.lblGas.Text = "Gas used(gallons)";
            this.lblGas.Click += new System.EventHandler(this.lblGas_Click);
            // 
            // txtGas
            // 
            this.txtGas.Location = new System.Drawing.Point(146, 115);
            this.txtGas.Name = "txtGas";
            this.txtGas.Size = new System.Drawing.Size(100, 20);
            this.txtGas.TabIndex = 4;
            // 
            // lblMPG
            // 
            this.lblMPG.AutoSize = true;
            this.lblMPG.Location = new System.Drawing.Point(37, 157);
            this.lblMPG.Name = "lblMPG";
            this.lblMPG.Size = new System.Drawing.Size(83, 13);
            this.lblMPG.TabIndex = 7;
            this.lblMPG.Text = "Miles per gallon:";
            // 
            // txtMPG
            // 
            this.txtMPG.Enabled = false;
            this.txtMPG.Location = new System.Drawing.Point(146, 157);
            this.txtMPG.Name = "txtMPG";
            this.txtMPG.Size = new System.Drawing.Size(100, 20);
            this.txtMPG.TabIndex = 6;
            // 
            // btnCompute
            // 
            this.btnCompute.Location = new System.Drawing.Point(65, 206);
            this.btnCompute.Name = "btnCompute";
            this.btnCompute.Size = new System.Drawing.Size(194, 35);
            this.btnCompute.TabIndex = 8;
            this.btnCompute.Text = "Compute";
            this.btnCompute.UseVisualStyleBackColor = true;
            this.btnCompute.Click += new System.EventHandler(this.btnCompute_Click);
            // 
            // MPG
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.btnCompute);
            this.Controls.Add(this.lblMPG);
            this.Controls.Add(this.txtMPG);
            this.Controls.Add(this.lblGas);
            this.Controls.Add(this.txtGas);
            this.Controls.Add(this.lblOdEnd);
            this.Controls.Add(this.txtOdEnd);
            this.Controls.Add(this.lblOdBeg);
            this.Controls.Add(this.txtOdBeg);
            this.Name = "MPG";
            this.Text = "Miles Per Gallon";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtOdBeg;
        private System.Windows.Forms.Label lblOdBeg;
        private System.Windows.Forms.Label lblOdEnd;
        private System.Windows.Forms.TextBox txtOdEnd;
        private System.Windows.Forms.Label lblGas;
        private System.Windows.Forms.TextBox txtGas;
        private System.Windows.Forms.Label lblMPG;
        private System.Windows.Forms.TextBox txtMPG;
        private System.Windows.Forms.Button btnCompute;
    }
}

