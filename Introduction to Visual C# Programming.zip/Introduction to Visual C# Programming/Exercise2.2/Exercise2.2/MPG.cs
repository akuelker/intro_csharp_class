﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Exercise2._2
{
    public partial class MPG : Form
    {
        public MPG()
        {
            InitializeComponent();
        }

        private void lblOdBeg_Click(object sender, EventArgs e)
        {

        }

        private void lblGas_Click(object sender, EventArgs e)
        {

        }

        private void btnCompute_Click(object sender, EventArgs e)
        {
            //inputs

            int intOdBeg = int.Parse(txtOdBeg.Text);
            int intOdEnd = int.Parse(txtOdEnd.Text);
            double dblGas = double.Parse(txtGas.Text);


            //process

            
            double dblMPG = (intOdEnd-intOdBeg)/dblGas;
           


            //outputs

            txtMPG.Text = dblMPG.ToString("N2");//must convert BACK to string. can add format specifiers. "C"
        }
    }
}
