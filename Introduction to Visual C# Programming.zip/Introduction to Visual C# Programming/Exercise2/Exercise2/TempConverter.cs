﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Exercise2
{
    public partial class TempConverter : Form
    {
        public TempConverter()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            double dblFahrenheit = double.Parse(txtFahrenheit.Text);
           double dblCelsius = 5.0 / 9.0 * (dblFahrenheit - 32);


            txtCelsius.Text = dblCelsius.ToString("N2");

        }
          
    }
}
