﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Exercise3._1
{
    public partial class VoteCalculater : Form
    {
        public VoteCalculater()
        {
            InitializeComponent();
        }

        private void btnVote_Click(object sender, EventArgs e)
        {
            int intAge = int.Parse(txtAge.Text);
            int AgeCalc = (18 - intAge);

            if (intAge >= 18)
                MessageBox.Show("Congratulations! You can vote!", "Voting Results", MessageBoxButtons.OK);
            else
                MessageBox.Show("You can vote in " + AgeCalc + " more years.", "Voting Results", MessageBoxButtons.OK);
        }

    }
}
