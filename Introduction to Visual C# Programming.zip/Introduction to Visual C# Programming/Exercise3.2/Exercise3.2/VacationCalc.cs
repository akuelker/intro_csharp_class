﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Exercise3._2
{
    public partial class VacationCalc : Form
    {
        public VacationCalc()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int intYears = int.Parse(txtYears.Text);
            int intVacation = 5;

            if (intYears >= 11)
                intVacation = 20;
            else if (intYears >= 6)
                intVacation = 15;
            else if (intYears >= 1)
                intVacation = 10;

            DialogResult result =
            MessageBox.Show("You get " + intVacation + " vacation days.", "Vacation Days", MessageBoxButtons.OK);

            if (result == DialogResult.OK)
                txtYears.Clear();
            txtYears.Focus();
        }
    }
}
