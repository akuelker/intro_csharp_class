﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Exercise3._3
{
    public partial class Grades : Form
    {
        public Grades()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
  
            {
                int intExamScore = int.Parse(txtExamScore.Text);
                String txtLetterGrade = "F";

                if (intExamScore >= 90)
                    txtLetterGrade = "A";
                else if (intExamScore >= 80)
                    txtLetterGrade = "B";
                else if (intExamScore >= 70)
                    txtLetterGrade = "C";
                else if (intExamScore >= 60)
                    txtLetterGrade = "D";

                MessageBox.Show("Your letter grade is " + txtLetterGrade + " .", "Letter Grade Calculation", MessageBoxButtons.OK);


            }
        }
    }
}
