﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Exercise4._1
{
    public partial class PaymentCalc : Form
    {
        public PaymentCalc()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double  dblBal = double.Parse(txtBalance.Text);
            double dblPmt = double.Parse(txtPayment.Text);

            double dblSavings = dblBal;
            int intMonths = 0;
            while (dblSavings >= dblBal)
            {
                dblSavings = dblBal - dblPmt;
                intMonths++;

            }
            if (dblSavings == 0) //pd evenly
                MessageBox.Show("You can payoff the loan in " + intMonths + " payments.", "Number of Payments", MessageBoxButtons.OK);

            else
            {
               
        }
        }
    }
}
