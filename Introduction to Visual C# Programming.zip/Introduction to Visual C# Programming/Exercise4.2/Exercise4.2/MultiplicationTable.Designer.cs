﻿namespace Exercise4._2
{
    partial class MultiplicationTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumber = new System.Windows.Forms.Label();
            this.txtNumber = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.lblOne = new System.Windows.Forms.Label();
            this.lblT1 = new System.Windows.Forms.Label();
            this.lblT2 = new System.Windows.Forms.Label();
            this.lblTwo = new System.Windows.Forms.Label();
            this.lblT3 = new System.Windows.Forms.Label();
            this.lblThree = new System.Windows.Forms.Label();
            this.lblT4 = new System.Windows.Forms.Label();
            this.lblFour = new System.Windows.Forms.Label();
            this.lblT5 = new System.Windows.Forms.Label();
            this.lblFive = new System.Windows.Forms.Label();
            this.lblT6 = new System.Windows.Forms.Label();
            this.lblSix = new System.Windows.Forms.Label();
            this.lblT7 = new System.Windows.Forms.Label();
            this.lblSeven = new System.Windows.Forms.Label();
            this.lblT8 = new System.Windows.Forms.Label();
            this.lblEight = new System.Windows.Forms.Label();
            this.lblT9 = new System.Windows.Forms.Label();
            this.lblNine = new System.Windows.Forms.Label();
            this.lblT10 = new System.Windows.Forms.Label();
            this.lblTen = new System.Windows.Forms.Label();
            this.lblT11 = new System.Windows.Forms.Label();
            this.lblEleven = new System.Windows.Forms.Label();
            this.lblT12 = new System.Windows.Forms.Label();
            this.lblTwelve = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNumber
            // 
            this.lblNumber.Location = new System.Drawing.Point(13, 27);
            this.lblNumber.Name = "lblNumber";
            this.lblNumber.Size = new System.Drawing.Size(100, 23);
            this.lblNumber.TabIndex = 0;
            this.lblNumber.Text = "Enter your number:";
            // 
            // txtNumber
            // 
            this.txtNumber.Location = new System.Drawing.Point(128, 27);
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.Size = new System.Drawing.Size(100, 20);
            this.txtNumber.TabIndex = 1;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(105, 522);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 23);
            this.btnCalculate.TabIndex = 2;
            this.btnCalculate.Text = "Show Table";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // lblOne
            // 
            this.lblOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOne.Location = new System.Drawing.Point(40, 74);
            this.lblOne.Name = "lblOne";
            this.lblOne.Size = new System.Drawing.Size(88, 20);
            this.lblOne.TabIndex = 3;
            this.lblOne.Text = "1 X";
            this.lblOne.Click += new System.EventHandler(this.lblTable_Click);
            // 
            // lblT1
            // 
            this.lblT1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT1.Location = new System.Drawing.Point(140, 74);
            this.lblT1.Name = "lblT1";
            this.lblT1.Size = new System.Drawing.Size(88, 20);
            this.lblT1.TabIndex = 4;
            // 
            // lblT2
            // 
            this.lblT2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT2.Location = new System.Drawing.Point(140, 112);
            this.lblT2.Name = "lblT2";
            this.lblT2.Size = new System.Drawing.Size(88, 20);
            this.lblT2.TabIndex = 6;
            // 
            // lblTwo
            // 
            this.lblTwo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTwo.Location = new System.Drawing.Point(40, 110);
            this.lblTwo.Name = "lblTwo";
            this.lblTwo.Size = new System.Drawing.Size(88, 20);
            this.lblTwo.TabIndex = 5;
            this.lblTwo.Text = "2 X";
            // 
            // lblT3
            // 
            this.lblT3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT3.Location = new System.Drawing.Point(140, 144);
            this.lblT3.Name = "lblT3";
            this.lblT3.Size = new System.Drawing.Size(88, 20);
            this.lblT3.TabIndex = 8;
            // 
            // lblThree
            // 
            this.lblThree.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblThree.Location = new System.Drawing.Point(40, 144);
            this.lblThree.Name = "lblThree";
            this.lblThree.Size = new System.Drawing.Size(88, 20);
            this.lblThree.TabIndex = 7;
            this.lblThree.Text = "3 X";
            // 
            // lblT4
            // 
            this.lblT4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT4.Location = new System.Drawing.Point(140, 174);
            this.lblT4.Name = "lblT4";
            this.lblT4.Size = new System.Drawing.Size(88, 20);
            this.lblT4.TabIndex = 10;
            // 
            // lblFour
            // 
            this.lblFour.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblFour.Location = new System.Drawing.Point(40, 174);
            this.lblFour.Name = "lblFour";
            this.lblFour.Size = new System.Drawing.Size(88, 20);
            this.lblFour.TabIndex = 9;
            this.lblFour.Text = "4 X";
            // 
            // lblT5
            // 
            this.lblT5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT5.Location = new System.Drawing.Point(140, 208);
            this.lblT5.Name = "lblT5";
            this.lblT5.Size = new System.Drawing.Size(88, 20);
            this.lblT5.TabIndex = 12;
            // 
            // lblFive
            // 
            this.lblFive.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblFive.Location = new System.Drawing.Point(40, 208);
            this.lblFive.Name = "lblFive";
            this.lblFive.Size = new System.Drawing.Size(88, 20);
            this.lblFive.TabIndex = 11;
            this.lblFive.Text = "5 X";
            // 
            // lblT6
            // 
            this.lblT6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT6.Location = new System.Drawing.Point(140, 243);
            this.lblT6.Name = "lblT6";
            this.lblT6.Size = new System.Drawing.Size(88, 20);
            this.lblT6.TabIndex = 14;
            // 
            // lblSix
            // 
            this.lblSix.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSix.Location = new System.Drawing.Point(40, 243);
            this.lblSix.Name = "lblSix";
            this.lblSix.Size = new System.Drawing.Size(88, 20);
            this.lblSix.TabIndex = 13;
            this.lblSix.Text = "6 X";
            // 
            // lblT7
            // 
            this.lblT7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT7.Location = new System.Drawing.Point(140, 279);
            this.lblT7.Name = "lblT7";
            this.lblT7.Size = new System.Drawing.Size(88, 20);
            this.lblT7.TabIndex = 16;
            // 
            // lblSeven
            // 
            this.lblSeven.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSeven.Location = new System.Drawing.Point(40, 279);
            this.lblSeven.Name = "lblSeven";
            this.lblSeven.Size = new System.Drawing.Size(88, 20);
            this.lblSeven.TabIndex = 15;
            this.lblSeven.Text = "7 X";
            // 
            // lblT8
            // 
            this.lblT8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT8.Location = new System.Drawing.Point(140, 314);
            this.lblT8.Name = "lblT8";
            this.lblT8.Size = new System.Drawing.Size(88, 20);
            this.lblT8.TabIndex = 18;
            // 
            // lblEight
            // 
            this.lblEight.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblEight.Location = new System.Drawing.Point(40, 314);
            this.lblEight.Name = "lblEight";
            this.lblEight.Size = new System.Drawing.Size(88, 20);
            this.lblEight.TabIndex = 17;
            this.lblEight.Text = "8 X";
            // 
            // lblT9
            // 
            this.lblT9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT9.Location = new System.Drawing.Point(140, 349);
            this.lblT9.Name = "lblT9";
            this.lblT9.Size = new System.Drawing.Size(88, 20);
            this.lblT9.TabIndex = 20;
            // 
            // lblNine
            // 
            this.lblNine.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblNine.Location = new System.Drawing.Point(40, 349);
            this.lblNine.Name = "lblNine";
            this.lblNine.Size = new System.Drawing.Size(88, 20);
            this.lblNine.TabIndex = 19;
            this.lblNine.Text = "9 X";
            // 
            // lblT10
            // 
            this.lblT10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT10.Location = new System.Drawing.Point(140, 385);
            this.lblT10.Name = "lblT10";
            this.lblT10.Size = new System.Drawing.Size(88, 20);
            this.lblT10.TabIndex = 22;
            // 
            // lblTen
            // 
            this.lblTen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTen.Location = new System.Drawing.Point(40, 385);
            this.lblTen.Name = "lblTen";
            this.lblTen.Size = new System.Drawing.Size(88, 20);
            this.lblTen.TabIndex = 21;
            this.lblTen.Text = "10 X";
            // 
            // lblT11
            // 
            this.lblT11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT11.Location = new System.Drawing.Point(140, 424);
            this.lblT11.Name = "lblT11";
            this.lblT11.Size = new System.Drawing.Size(88, 20);
            this.lblT11.TabIndex = 24;
            // 
            // lblEleven
            // 
            this.lblEleven.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblEleven.Location = new System.Drawing.Point(40, 424);
            this.lblEleven.Name = "lblEleven";
            this.lblEleven.Size = new System.Drawing.Size(88, 20);
            this.lblEleven.TabIndex = 23;
            this.lblEleven.Text = "11 X";
            // 
            // lblT12
            // 
            this.lblT12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblT12.Location = new System.Drawing.Point(140, 460);
            this.lblT12.Name = "lblT12";
            this.lblT12.Size = new System.Drawing.Size(88, 20);
            this.lblT12.TabIndex = 26;
            // 
            // lblTwelve
            // 
            this.lblTwelve.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTwelve.Location = new System.Drawing.Point(40, 460);
            this.lblTwelve.Name = "lblTwelve";
            this.lblTwelve.Size = new System.Drawing.Size(88, 20);
            this.lblTwelve.TabIndex = 25;
            this.lblTwelve.Text = "12 X";
            // 
            // MultiplicationTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(281, 555);
            this.Controls.Add(this.lblT12);
            this.Controls.Add(this.lblTwelve);
            this.Controls.Add(this.lblT11);
            this.Controls.Add(this.lblEleven);
            this.Controls.Add(this.lblT10);
            this.Controls.Add(this.lblTen);
            this.Controls.Add(this.lblT9);
            this.Controls.Add(this.lblNine);
            this.Controls.Add(this.lblT8);
            this.Controls.Add(this.lblEight);
            this.Controls.Add(this.lblT7);
            this.Controls.Add(this.lblSeven);
            this.Controls.Add(this.lblT6);
            this.Controls.Add(this.lblSix);
            this.Controls.Add(this.lblT5);
            this.Controls.Add(this.lblFive);
            this.Controls.Add(this.lblT4);
            this.Controls.Add(this.lblFour);
            this.Controls.Add(this.lblT3);
            this.Controls.Add(this.lblThree);
            this.Controls.Add(this.lblT2);
            this.Controls.Add(this.lblTwo);
            this.Controls.Add(this.lblT1);
            this.Controls.Add(this.lblOne);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtNumber);
            this.Controls.Add(this.lblNumber);
            this.Name = "MultiplicationTable";
            this.Text = "Multiplication Table";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumber;
        private System.Windows.Forms.TextBox txtNumber;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label lblOne;
        private System.Windows.Forms.Label lblT1;
        private System.Windows.Forms.Label lblT2;
        private System.Windows.Forms.Label lblTwo;
        private System.Windows.Forms.Label lblT3;
        private System.Windows.Forms.Label lblThree;
        private System.Windows.Forms.Label lblT4;
        private System.Windows.Forms.Label lblFour;
        private System.Windows.Forms.Label lblT5;
        private System.Windows.Forms.Label lblFive;
        private System.Windows.Forms.Label lblT6;
        private System.Windows.Forms.Label lblSix;
        private System.Windows.Forms.Label lblT7;
        private System.Windows.Forms.Label lblSeven;
        private System.Windows.Forms.Label lblT8;
        private System.Windows.Forms.Label lblEight;
        private System.Windows.Forms.Label lblT9;
        private System.Windows.Forms.Label lblNine;
        private System.Windows.Forms.Label lblT10;
        private System.Windows.Forms.Label lblTen;
        private System.Windows.Forms.Label lblT11;
        private System.Windows.Forms.Label lblEleven;
        private System.Windows.Forms.Label lblT12;
        private System.Windows.Forms.Label lblTwelve;
    }
}

