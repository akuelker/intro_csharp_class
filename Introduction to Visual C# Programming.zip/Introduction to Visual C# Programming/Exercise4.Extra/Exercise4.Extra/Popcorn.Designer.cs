﻿namespace Exercise4.Extra
{
    partial class Popcorn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEaters = new System.Windows.Forms.Label();
            this.txtEaters = new System.Windows.Forms.TextBox();
            this.lblLarge = new System.Windows.Forms.Label();
            this.lblGrande = new System.Windows.Forms.Label();
            this.lblJumbo = new System.Windows.Forms.Label();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.txtLarge = new System.Windows.Forms.TextBox();
            this.txtGrande = new System.Windows.Forms.TextBox();
            this.txtJumbo = new System.Windows.Forms.TextBox();
            this.txtTotalCost = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblEaters
            // 
            this.lblEaters.Location = new System.Drawing.Point(13, 26);
            this.lblEaters.Name = "lblEaters";
            this.lblEaters.Size = new System.Drawing.Size(100, 38);
            this.lblEaters.TabIndex = 0;
            this.lblEaters.Text = "Number of Popcorn Eaters";
            // 
            // txtEaters
            // 
            this.txtEaters.Location = new System.Drawing.Point(119, 26);
            this.txtEaters.Name = "txtEaters";
            this.txtEaters.Size = new System.Drawing.Size(100, 20);
            this.txtEaters.TabIndex = 1;
            // 
            // lblLarge
            // 
            this.lblLarge.AutoSize = true;
            this.lblLarge.Location = new System.Drawing.Point(13, 116);
            this.lblLarge.Name = "lblLarge";
            this.lblLarge.Size = new System.Drawing.Size(37, 13);
            this.lblLarge.TabIndex = 2;
            this.lblLarge.Text = "Large:";
            // 
            // lblGrande
            // 
            this.lblGrande.AutoSize = true;
            this.lblGrande.Location = new System.Drawing.Point(13, 145);
            this.lblGrande.Name = "lblGrande";
            this.lblGrande.Size = new System.Drawing.Size(45, 13);
            this.lblGrande.TabIndex = 3;
            this.lblGrande.Text = "Grande:";
            // 
            // lblJumbo
            // 
            this.lblJumbo.AutoSize = true;
            this.lblJumbo.Location = new System.Drawing.Point(13, 174);
            this.lblJumbo.Name = "lblJumbo";
            this.lblJumbo.Size = new System.Drawing.Size(41, 13);
            this.lblJumbo.TabIndex = 4;
            this.lblJumbo.Text = "Jumbo:";
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.AutoSize = true;
            this.lblTotalCost.Location = new System.Drawing.Point(13, 209);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(58, 13);
            this.lblTotalCost.TabIndex = 5;
            this.lblTotalCost.Text = "Total Cost:";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(16, 67);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(203, 23);
            this.btnCalculate.TabIndex = 6;
            this.btnCalculate.Text = "Calculate Number of Popcorn Eaters";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // txtLarge
            // 
            this.txtLarge.BackColor = System.Drawing.SystemColors.Control;
            this.txtLarge.Enabled = false;
            this.txtLarge.Location = new System.Drawing.Point(104, 116);
            this.txtLarge.Name = "txtLarge";
            this.txtLarge.Size = new System.Drawing.Size(100, 20);
            this.txtLarge.TabIndex = 7;
            // 
            // txtGrande
            // 
            this.txtGrande.BackColor = System.Drawing.SystemColors.Control;
            this.txtGrande.Enabled = false;
            this.txtGrande.Location = new System.Drawing.Point(104, 145);
            this.txtGrande.Name = "txtGrande";
            this.txtGrande.Size = new System.Drawing.Size(100, 20);
            this.txtGrande.TabIndex = 8;
            // 
            // txtJumbo
            // 
            this.txtJumbo.BackColor = System.Drawing.SystemColors.Control;
            this.txtJumbo.Enabled = false;
            this.txtJumbo.Location = new System.Drawing.Point(104, 174);
            this.txtJumbo.Name = "txtJumbo";
            this.txtJumbo.Size = new System.Drawing.Size(100, 20);
            this.txtJumbo.TabIndex = 9;
            this.txtJumbo.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // txtTotalCost
            // 
            this.txtTotalCost.BackColor = System.Drawing.SystemColors.Control;
            this.txtTotalCost.Enabled = false;
            this.txtTotalCost.Location = new System.Drawing.Point(104, 210);
            this.txtTotalCost.Name = "txtTotalCost";
            this.txtTotalCost.Size = new System.Drawing.Size(100, 20);
            this.txtTotalCost.TabIndex = 10;
            this.txtTotalCost.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // Popcorn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.txtTotalCost);
            this.Controls.Add(this.txtJumbo);
            this.Controls.Add(this.txtGrande);
            this.Controls.Add(this.txtLarge);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.lblTotalCost);
            this.Controls.Add(this.lblJumbo);
            this.Controls.Add(this.lblGrande);
            this.Controls.Add(this.lblLarge);
            this.Controls.Add(this.txtEaters);
            this.Controls.Add(this.lblEaters);
            this.Name = "Popcorn";
            this.Text = "Popcorn Eaters";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEaters;
        private System.Windows.Forms.TextBox txtEaters;
        private System.Windows.Forms.Label lblLarge;
        private System.Windows.Forms.Label lblGrande;
        private System.Windows.Forms.Label lblJumbo;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.TextBox txtLarge;
        private System.Windows.Forms.TextBox txtGrande;
        private System.Windows.Forms.TextBox txtJumbo;
        private System.Windows.Forms.TextBox txtTotalCost;
    }
}

