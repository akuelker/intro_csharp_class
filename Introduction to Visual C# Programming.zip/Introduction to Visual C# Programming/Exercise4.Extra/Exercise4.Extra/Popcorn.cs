﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Exercise4.Extra
{
    public partial class Popcorn : Form
    {
        public Popcorn()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int intEaters = int.Parse(txtEaters.Text);

            int intLarge = 0;
            int intGrande = 0;
            int intJumbo = 0;

            double dblLargePrice = 5.75;
            double dblGrandePrice = 7.95;
            double dblJumboPrice = 9.95;
            double dblTotalPrice = 0;

            //order jumbos as long as you have 3 or more

            while (intEaters >= 3)
            {
                intJumbo++;
                    dblTotalPrice += dblJumboPrice;
                intEaters -=3;
            }

            //less than 3 people left

            if (intEaters -=3)
            {
                intLarge ++;
                    dblTotalPrice += dblLargePrice;
                }

            else if (intEaters ==2)
            {
                intGrande++;
                dblTotalPrice += dblGrandePrice;
            }


            //output

            txtLarge.Text = intLarge.ToString();
            txtGrande.Text = intGrande.ToString();
            txtJumbo.Text = intJumbo.ToString();
            txtTotalCost.Text = dblTotalPrice.ToString();
        }
    }
}
