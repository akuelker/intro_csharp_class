﻿namespace Exercise5.Extra
{
    partial class CommunityCenterDues
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblReg = new System.Windows.Forms.Label();
            this.lblDisc = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.cboCity = new System.Windows.Forms.ComboBox();
            this.txtReg = new System.Windows.Forms.TextBox();
            this.txtDisc = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(13, 13);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(79, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Member Name:";
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(13, 46);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(69, 13);
            this.lblCity.TabIndex = 1;
            this.lblCity.Text = "Select a City:";
            // 
            // lblReg
            // 
            this.lblReg.AutoSize = true;
            this.lblReg.Location = new System.Drawing.Point(13, 135);
            this.lblReg.Name = "lblReg";
            this.lblReg.Size = new System.Drawing.Size(75, 13);
            this.lblReg.TabIndex = 2;
            this.lblReg.Text = "Regular Dues:";
            // 
            // lblDisc
            // 
            this.lblDisc.AutoSize = true;
            this.lblDisc.Location = new System.Drawing.Point(13, 179);
            this.lblDisc.Name = "lblDisc";
            this.lblDisc.Size = new System.Drawing.Size(52, 13);
            this.lblDisc.TabIndex = 3;
            this.lblDisc.Text = "Discount:";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(13, 223);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(62, 13);
            this.lblTotal.TabIndex = 4;
            this.lblTotal.Text = "Total Dues:";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(16, 81);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(256, 35);
            this.btnCalculate.TabIndex = 5;
            this.btnCalculate.Text = "Calculate Member Dues";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(115, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(157, 20);
            this.textBox1.TabIndex = 6;
            // 
            // cboCity
            // 
            this.cboCity.AutoCompleteCustomSource.AddRange(new string[] {
            "Chesterfield",
            "Clayton",
            "Des Peres",
            "Kirkwood",
            "Maplewood",
            "Webster Groves"});
            this.cboCity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCity.FormattingEnabled = true;
            this.cboCity.Items.AddRange(new object[] {
            "Chesterfield",
            "Kirkwood",
            "Des Peres",
            "Clayton",
            "Webster Groves",
            "Maplewood"});
            this.cboCity.Location = new System.Drawing.Point(115, 46);
            this.cboCity.Name = "cboCity";
            this.cboCity.Size = new System.Drawing.Size(157, 21);
            this.cboCity.TabIndex = 7;
            // 
            // txtReg
            // 
            this.txtReg.BackColor = System.Drawing.SystemColors.Control;
            this.txtReg.Enabled = false;
            this.txtReg.Location = new System.Drawing.Point(152, 135);
            this.txtReg.Name = "txtReg";
            this.txtReg.Size = new System.Drawing.Size(100, 20);
            this.txtReg.TabIndex = 8;
            this.txtReg.Text = "$100.00";
            // 
            // txtDisc
            // 
            this.txtDisc.BackColor = System.Drawing.SystemColors.Control;
            this.txtDisc.Enabled = false;
            this.txtDisc.Location = new System.Drawing.Point(152, 179);
            this.txtDisc.Name = "txtDisc";
            this.txtDisc.Size = new System.Drawing.Size(100, 20);
            this.txtDisc.TabIndex = 9;
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.SystemColors.Control;
            this.txtTotal.Enabled = false;
            this.txtTotal.Location = new System.Drawing.Point(152, 223);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(100, 20);
            this.txtTotal.TabIndex = 10;
            // 
            // CommunityCenterDues
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.txtDisc);
            this.Controls.Add(this.txtReg);
            this.Controls.Add(this.cboCity);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblDisc);
            this.Controls.Add(this.lblReg);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.lblName);
            this.Name = "CommunityCenterDues";
            this.Text = "Community Center Dues";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblReg;
        private System.Windows.Forms.Label lblDisc;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox cboCity;
        private System.Windows.Forms.TextBox txtReg;
        private System.Windows.Forms.TextBox txtDisc;
        private System.Windows.Forms.TextBox txtTotal;
    }
}

