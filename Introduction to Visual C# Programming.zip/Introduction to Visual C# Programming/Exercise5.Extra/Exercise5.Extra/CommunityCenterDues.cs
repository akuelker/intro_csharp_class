﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Exercise5.Extra
{
    public partial class CommunityCenterDues : Form
    {
        public CommunityCenterDues()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            
            switch (cboCity.SelectedIndex)
            {
                case 0:
                    double dblDisc = .05;
                    txtDisc.Text = "5%";
                    double dblTotal = 100 * (1 - dblDisc);
                    txtTotal.Text = dblTotal.ToString("C");
                    break;
                case 1:
                    double dblDisc1 = .05;
                    txtDisc.Text = "5%";
                    double dblTotal1 = 100 * (1 - dblDisc1);
                    txtTotal.Text = dblTotal1.ToString("C");
                    break;
                case 2:
                    double dblDisc2 = .10;
                    txtDisc.Text = "10%";
                    double dblTotal2 = 100 * (1 - dblDisc2);
                    txtTotal.Text = dblTotal2.ToString("C");
                    break;
                case 3:
                    double dblDisc3 = .10;
                    txtDisc.Text = "10%";
                    double dblTotal3 = 100 * (1 - dblDisc3);
                    txtTotal.Text = dblTotal3.ToString("C");
                   

                    break;
                case 4:
                    double dblDisc4 = .20;
                    txtDisc.Text = "20%";
                    double dblTotal4 = 100 * (1 - dblDisc4);
                    txtTotal.Text = dblTotal4.ToString("C");
                    
                    break;
                case 5:
                    double dblDisc5 = .20;
                    txtDisc.Text = "20%";
                     double dblTotal5 = 100 * (1 - dblDisc5);
                     txtTotal.Text = dblTotal5.ToString("C");                 
                    
                    break;


            }
        }
    }
}
