﻿namespace Exercise6._2
{
    partial class Hotel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radEconomy = new System.Windows.Forms.RadioButton();
            this.radStandard = new System.Windows.Forms.RadioButton();
            this.radLuxury = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkSpa = new System.Windows.Forms.CheckBox();
            this.chkBreakfast = new System.Windows.Forms.CheckBox();
            this.chkTheater = new System.Windows.Forms.CheckBox();
            this.chkGolf = new System.Windows.Forms.CheckBox();
            this.lblNights = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.lblTotal = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.cboNights = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radLuxury);
            this.groupBox1.Controls.Add(this.radStandard);
            this.groupBox1.Controls.Add(this.radEconomy);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(197, 107);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Room Quality";
            // 
            // radEconomy
            // 
            this.radEconomy.AutoSize = true;
            this.radEconomy.Checked = true;
            this.radEconomy.Location = new System.Drawing.Point(7, 20);
            this.radEconomy.Name = "radEconomy";
            this.radEconomy.Size = new System.Drawing.Size(171, 17);
            this.radEconomy.TabIndex = 0;
            this.radEconomy.TabStop = true;
            this.radEconomy.Text = "Economy Room ($50 per night)";
            this.radEconomy.UseVisualStyleBackColor = true;
            // 
            // radStandard
            // 
            this.radStandard.AutoSize = true;
            this.radStandard.Location = new System.Drawing.Point(7, 51);
            this.radStandard.Name = "radStandard";
            this.radStandard.Size = new System.Drawing.Size(176, 17);
            this.radStandard.TabIndex = 1;
            this.radStandard.TabStop = true;
            this.radStandard.Text = "Standard Room ($100 per night)";
            this.radStandard.UseVisualStyleBackColor = true;
            // 
            // radLuxury
            // 
            this.radLuxury.AutoSize = true;
            this.radLuxury.Location = new System.Drawing.Point(7, 82);
            this.radLuxury.Name = "radLuxury";
            this.radLuxury.Size = new System.Drawing.Size(164, 17);
            this.radLuxury.TabIndex = 2;
            this.radLuxury.TabStop = true;
            this.radLuxury.Text = "Luxury Room ($150 per night)";
            this.radLuxury.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chkGolf);
            this.groupBox2.Controls.Add(this.chkTheater);
            this.groupBox2.Controls.Add(this.chkBreakfast);
            this.groupBox2.Controls.Add(this.chkSpa);
            this.groupBox2.Location = new System.Drawing.Point(19, 144);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(297, 112);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Extras";
            // 
            // chkSpa
            // 
            this.chkSpa.AutoSize = true;
            this.chkSpa.Location = new System.Drawing.Point(7, 20);
            this.chkSpa.Name = "chkSpa";
            this.chkSpa.Size = new System.Drawing.Size(135, 17);
            this.chkSpa.TabIndex = 0;
            this.chkSpa.Text = "Spa Treatment (+$250)";
            this.chkSpa.UseVisualStyleBackColor = true;
            // 
            // chkBreakfast
            // 
            this.chkBreakfast.AutoSize = true;
            this.chkBreakfast.Location = new System.Drawing.Point(7, 43);
            this.chkBreakfast.Name = "chkBreakfast";
            this.chkBreakfast.Size = new System.Drawing.Size(179, 17);
            this.chkBreakfast.TabIndex = 1;
            this.chkBreakfast.Text = "Breakfast Buffet (+$10 per night)";
            this.chkBreakfast.UseVisualStyleBackColor = true;
            // 
            // chkTheater
            // 
            this.chkTheater.AutoSize = true;
            this.chkTheater.Location = new System.Drawing.Point(7, 66);
            this.chkTheater.Name = "chkTheater";
            this.chkTheater.Size = new System.Drawing.Size(134, 17);
            this.chkTheater.TabIndex = 2;
            this.chkTheater.Text = "Theater Tickets (+$50)";
            this.chkTheater.UseVisualStyleBackColor = true;
            // 
            // chkGolf
            // 
            this.chkGolf.AutoSize = true;
            this.chkGolf.Location = new System.Drawing.Point(7, 89);
            this.chkGolf.Name = "chkGolf";
            this.chkGolf.Size = new System.Drawing.Size(78, 17);
            this.chkGolf.TabIndex = 3;
            this.chkGolf.Text = "Golf (+$80)";
            this.chkGolf.UseVisualStyleBackColor = true;
            // 
            // lblNights
            // 
            this.lblNights.AutoSize = true;
            this.lblNights.Location = new System.Drawing.Point(235, 13);
            this.lblNights.Name = "lblNights";
            this.lblNights.Size = new System.Drawing.Size(40, 13);
            this.lblNights.TabIndex = 2;
            this.lblNights.Text = "Nights:";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(71, 263);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(214, 28);
            this.btnCalculate.TabIndex = 3;
            this.btnCalculate.Text = "Calculate Price";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(97, 316);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(34, 13);
            this.lblTotal.TabIndex = 4;
            this.lblTotal.Text = "Total:";
            // 
            // txtTotal
            // 
            this.txtTotal.Enabled = false;
            this.txtTotal.ForeColor = System.Drawing.SystemColors.Control;
            this.txtTotal.Location = new System.Drawing.Point(137, 309);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(116, 20);
            this.txtTotal.TabIndex = 5;
            // 
            // cboNights
            // 
            this.cboNights.FormattingEnabled = true;
            this.cboNights.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cboNights.Location = new System.Drawing.Point(238, 29);
            this.cboNights.Name = "cboNights";
            this.cboNights.Size = new System.Drawing.Size(79, 21);
            this.cboNights.TabIndex = 6;
            // 
            // Hotel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(351, 338);
            this.Controls.Add(this.cboNights);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.lblNights);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Hotel";
            this.Text = "Hotel Form";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radLuxury;
        private System.Windows.Forms.RadioButton radStandard;
        private System.Windows.Forms.RadioButton radEconomy;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chkGolf;
        private System.Windows.Forms.CheckBox chkTheater;
        private System.Windows.Forms.CheckBox chkBreakfast;
        private System.Windows.Forms.CheckBox chkSpa;
        private System.Windows.Forms.Label lblNights;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.ComboBox cboNights;
    }
}

