﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Exercise6._2
{
    public partial class Hotel : Form
    {
        public Hotel()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int intNights = int.Parse(cboNights.Text);
            double dblTotal = 0;

            if (radEconomy.Checked)
            {
                dblTotal = intNights * 50;
            }
            else if (radStandard.Checked)
            {
                dblTotal = intNights * 100;
            }
            else if (radLuxury.Checked)
            {
                dblTotal = intNights * 150;
            }

            if (chkSpa.Checked)
            {
                dblTotal += 250;
            }

            if (chkBreakfast.Checked)
            {
                dblTotal += 10 * intNights;
            }

            if (chkTheater.Checked)
            {
                dblTotal += 50;
            }

            if (chkGolf.Checked)
            {
                dblTotal += 80;
            }

            txtTotal.Text = dblTotal.ToString("C");
        }
    }
}
