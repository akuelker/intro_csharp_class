﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FontAndColor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radBlack_CheckedChanged(object sender, EventArgs e)
        {
            lblSample.ForeColor = Color.Black;
        }

        private void radRed_CheckedChanged(object sender, EventArgs e)
        {
            lblSample.ForeColor = Color.Red;
        }

        private void radBlue_CheckedChanged(object sender, EventArgs e)
        {
            lblSample.ForeColor = Color.Blue;
        }

        private void chkBold_CheckedChanged(object sender, EventArgs e)
        {
            FontStyle newStyle;

            if (chkBold.Checked && chkItalic.Checked)
                newStyle = FontStyle.Bold | FontStyle.Italic;  //joins two styles
            else if (chkBold.Checked)
                newStyle = FontStyle.Bold;
            else if (chkItalic.Checked)
                newStyle = FontStyle.Italic;
            else
                newStyle = FontStyle.Regular;

            lblSample.Font = new Font(lblSample.Font.Name,
                                        lblSample.Font.Size,
                                         newStyle);  //need all three, two stay the same

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (FontFamily font in FontFamily.Families)  //add all regular fonts available
            {
                if (font.IsStyleAvailable(FontStyle.Regular))
                lstFontNames.Items.Add(font.Name);
                lblSize.Text = trkSize.Value.ToString();
            }

            lstFontNames.SelectedItem = "Comic Sans MS";
            lblSample.Text = lstFontNames.SelectedItem.ToString();
        }

        private void lstFontNames_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblSample.Font = new Font(lstFontNames.SelectedItem.ToString(),
                                        lblSample.Font.Size,
                                         lblSample.Font.Style);

            lblSample.Text = lstFontNames.SelectedItem.ToString();
        }

        private void trkSize_Scroll(object sender, EventArgs e)
        {
            lblSample.Font = new Font(lblSample.Font.Name,
                                        trkSize.Value,
                                         lblSample.Font.Style);
            lblSize.Text = trkSize.Value.ToString();
            //p105
        }
    }
}
