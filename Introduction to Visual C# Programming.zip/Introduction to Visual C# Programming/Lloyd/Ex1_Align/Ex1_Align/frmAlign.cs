﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex1_Align
{
    public partial class frmAlign : Form
    {
        public frmAlign()
        {
            InitializeComponent();
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {
            lblAlign.Text = "LEFT";
            lblAlign.TextAlign = ContentAlignment.MiddleLeft;
            btnLeft.Enabled = false;
            btnCenter.Enabled = true;
            btnRight.Enabled = true;
        }

        private void btnCenter_Click(object sender, EventArgs e)
        {
            lblAlign.Text = "CENTER";
            lblAlign.TextAlign = ContentAlignment.MiddleCenter;
            btnLeft.Enabled = true;
            btnCenter.Enabled = false;
            btnRight.Enabled = true;
        }

        private void btnRight_Click(object sender, EventArgs e)
        {
            lblAlign.Text = "RIGHT";
            lblAlign.TextAlign = ContentAlignment.MiddleRight;
            btnLeft.Enabled = true;
            btnCenter.Enabled = true;
            btnRight.Enabled = false;
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmAlign_Load(object sender, EventArgs e)
        {
            cboAlign.SelectedIndex = 0;
        }

        private void cboAlign_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cboAlign.SelectedIndex)
            {
                case 0:
                    btnLeft_Click(sender, e);
                    break;
                case 1:
                    btnCenter_Click(sender, e);
                    break;
                case 2:
                    btnRight_Click(sender, e);
                    break;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            btnLeft_Click(sender, e);
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            btnCenter_Click(sender, e);
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            btnRight_Click(sender, e);
        }
    }
}
