﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex4_Loan
{
    public partial class frmLoan : Form
    {
        public frmLoan()
        {
            InitializeComponent();
        }

        private void btnCompute_Click(object sender, EventArgs e)
        {
            double dblBal = double.Parse(txtBal.Text);
            double dblPymt = double.Parse(txtPayment.Text);
            int intNumPayments = 0;

            while (dblBal >= dblPymt)
            {
                dblBal -= dblPymt;
                intNumPayments++;
            }

            if (dblBal == 0) // paid off evenly
                MessageBox.Show("You can payoff the loan in " +
                    intNumPayments + " regular payments.",
                    "Number of Payments");
            else
                MessageBox.Show("You can payoff the loan in " +
                  intNumPayments + " regular payments.\n" + 
                  "Plus one additional payment of " + dblBal.ToString("C"),
                  "Number of Payments");

        }
    }
}
