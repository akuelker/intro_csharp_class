﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex4_Popcorn
{
    public partial class frmPop : Form
    {
        public frmPop()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            int intEaters = int.Parse(txtEaters.Text);
            double dblTotal = 0;
            txtLarge.Clear();
            txtGrande.Clear();
            txtJumbo.Clear();
            txtTotal.Clear();

            int intLarge = 0;
            int intGrande = 0;
            int intJumbo = 0;

            while (intEaters > 0)
            {
                if (intEaters >= 3)
                {
                    intJumbo += (intEaters / 3);
                    intEaters = intEaters % 3;
                }
                else if (intEaters >= 2)
                {
                    intGrande += (intEaters / 2);
                    intEaters = intEaters % 2;
                }
                else
                {
                    intLarge += 1;
                    intEaters -= 1;
                }
            }

            dblTotal += (intLarge * 5.75) + 
                        (intGrande * 7.95) +
                        (intJumbo * 9.95);

            txtLarge.Text = intLarge.ToString();
            txtGrande.Text = intGrande.ToString();
            txtJumbo.Text = intJumbo.ToString();
            txtTotal.Text = dblTotal.ToString("C");

        }

        
    }
}
