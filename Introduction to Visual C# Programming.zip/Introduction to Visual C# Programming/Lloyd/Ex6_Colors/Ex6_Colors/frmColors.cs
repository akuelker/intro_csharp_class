﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex6_Colors
{
    public partial class frmColors : Form
    {
        public frmColors()
        {
            InitializeComponent();
        }

        private void frmColors_Load(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(trkRed.Value,
                                            trkGreen.Value,
                                            trkBlue.Value);

            lblRed.Text = "Red: " + trkRed.Value.ToString();
            lblGreen.Text = "Green: " + trkGreen.Value.ToString();
            lblBlue.Text = "Blue: " + trkBlue.Value.ToString();

            if (trkRed.Value < 127 && trkGreen.Value < 127 &&
                trkBlue.Value < 127)
            {
                lblRed.ForeColor = Color.White;
                lblGreen.ForeColor = Color.White;
                lblBlue.ForeColor = Color.White;
            }
            else if (trkRed.Value > 127 && trkGreen.Value > 127 &&
               trkBlue.Value > 127)
            {
                lblRed.ForeColor = Color.Black;
                lblGreen.ForeColor = Color.Black;
                lblBlue.ForeColor = Color.Black;
            }
        }
    }
}
