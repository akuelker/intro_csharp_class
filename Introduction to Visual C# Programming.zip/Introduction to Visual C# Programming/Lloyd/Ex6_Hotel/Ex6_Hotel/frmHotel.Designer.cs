﻿namespace Ex6_Hotel
{
    partial class frmHotel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cboNights = new System.Windows.Forms.ComboBox();
            this.radEcon = new System.Windows.Forms.RadioButton();
            this.radStand = new System.Windows.Forms.RadioButton();
            this.radLux = new System.Windows.Forms.RadioButton();
            this.chkSpa = new System.Windows.Forms.CheckBox();
            this.chkBuffet = new System.Windows.Forms.CheckBox();
            this.chkTix = new System.Windows.Forms.CheckBox();
            this.chkGolf = new System.Windows.Forms.CheckBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radLux);
            this.groupBox1.Controls.Add(this.radStand);
            this.groupBox1.Controls.Add(this.radEcon);
            this.groupBox1.Location = new System.Drawing.Point(12, 9);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(186, 125);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Room Quality";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chkGolf);
            this.groupBox2.Controls.Add(this.chkTix);
            this.groupBox2.Controls.Add(this.chkBuffet);
            this.groupBox2.Controls.Add(this.chkSpa);
            this.groupBox2.Location = new System.Drawing.Point(12, 140);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(212, 125);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Extras";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(204, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nights:";
            // 
            // cboNights
            // 
            this.cboNights.FormattingEnabled = true;
            this.cboNights.Location = new System.Drawing.Point(207, 25);
            this.cboNights.Name = "cboNights";
            this.cboNights.Size = new System.Drawing.Size(71, 21);
            this.cboNights.TabIndex = 2;
            // 
            // radEcon
            // 
            this.radEcon.AutoSize = true;
            this.radEcon.Location = new System.Drawing.Point(7, 26);
            this.radEcon.Name = "radEcon";
            this.radEcon.Size = new System.Drawing.Size(171, 17);
            this.radEcon.TabIndex = 0;
            this.radEcon.TabStop = true;
            this.radEcon.Text = "Economy Room ($50 per night)";
            this.radEcon.UseVisualStyleBackColor = true;
            // 
            // radStand
            // 
            this.radStand.AutoSize = true;
            this.radStand.Location = new System.Drawing.Point(7, 63);
            this.radStand.Name = "radStand";
            this.radStand.Size = new System.Drawing.Size(176, 17);
            this.radStand.TabIndex = 1;
            this.radStand.TabStop = true;
            this.radStand.Text = "Standard Room ($100 per night)";
            this.radStand.UseVisualStyleBackColor = true;
            // 
            // radLux
            // 
            this.radLux.AutoSize = true;
            this.radLux.Location = new System.Drawing.Point(7, 102);
            this.radLux.Name = "radLux";
            this.radLux.Size = new System.Drawing.Size(164, 17);
            this.radLux.TabIndex = 2;
            this.radLux.TabStop = true;
            this.radLux.Text = "Luxury Room ($150 per night)";
            this.radLux.UseVisualStyleBackColor = true;
            // 
            // chkSpa
            // 
            this.chkSpa.AutoSize = true;
            this.chkSpa.Location = new System.Drawing.Point(6, 31);
            this.chkSpa.Name = "chkSpa";
            this.chkSpa.Size = new System.Drawing.Size(138, 17);
            this.chkSpa.TabIndex = 0;
            this.chkSpa.Text = "Spa Treatment (+ $250)";
            this.chkSpa.UseVisualStyleBackColor = true;
            // 
            // chkBuffet
            // 
            this.chkBuffet.AutoSize = true;
            this.chkBuffet.Location = new System.Drawing.Point(6, 54);
            this.chkBuffet.Name = "chkBuffet";
            this.chkBuffet.Size = new System.Drawing.Size(182, 17);
            this.chkBuffet.TabIndex = 1;
            this.chkBuffet.Text = "Breakfast Buffet (+ $10 per night)";
            this.chkBuffet.UseVisualStyleBackColor = true;
            // 
            // chkTix
            // 
            this.chkTix.AutoSize = true;
            this.chkTix.Location = new System.Drawing.Point(6, 77);
            this.chkTix.Name = "chkTix";
            this.chkTix.Size = new System.Drawing.Size(134, 17);
            this.chkTix.TabIndex = 2;
            this.chkTix.Text = "Theater Tickets(+ $50)";
            this.chkTix.UseVisualStyleBackColor = true;
            // 
            // chkGolf
            // 
            this.chkGolf.AutoSize = true;
            this.chkGolf.Location = new System.Drawing.Point(6, 102);
            this.chkGolf.Name = "chkGolf";
            this.chkGolf.Size = new System.Drawing.Size(81, 17);
            this.chkGolf.TabIndex = 3;
            this.chkGolf.Text = "Golf (+ $80)";
            this.chkGolf.UseVisualStyleBackColor = true;
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(72, 280);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(128, 28);
            this.btnCalc.TabIndex = 3;
            this.btnCalc.Text = "Calculate Price";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // frmHotel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(290, 325);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.cboNights);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmHotel";
            this.Text = "Hotel California";
            this.Load += new System.EventHandler(this.frmHotel_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radLux;
        private System.Windows.Forms.RadioButton radStand;
        private System.Windows.Forms.RadioButton radEcon;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chkGolf;
        private System.Windows.Forms.CheckBox chkTix;
        private System.Windows.Forms.CheckBox chkBuffet;
        private System.Windows.Forms.CheckBox chkSpa;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboNights;
        private System.Windows.Forms.Button btnCalc;
    }
}

