﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ex6_Hotel
{
    public partial class frmHotel : Form
    {
        public frmHotel()
        {
            InitializeComponent();
        }

        private void frmHotel_Load(object sender, EventArgs e)
        {
            for (int i = 1; i <= 30; i++)
            {
                cboNights.Items.Add(i.ToString());
               

            }
            cboNights.SelectedIndex = 1;
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            string stayInfo = "";
            double dblTotal = 0;
            int intNights = int.Parse(cboNights.Text);

            if (radEcon.Checked)
            {
                stayInfo += intNights + " night(s) in our Economy Room\n";
                dblTotal += (intNights * 50);
            }
            if (radStand.Checked)
            {
                stayInfo += intNights + " night(s) in our Standard Double Room\n";
                dblTotal += (intNights * 100);
            }
            if (radLux.Checked)
            {
                stayInfo += intNights + " night(s) in our Luxury Penthouse Suite\n";
                dblTotal += (intNights * 150);
            }

            if (chkSpa.Checked)
            {
                stayInfo += "Enjoy a day of pampering in our Spa\n";
                dblTotal += 250;
            }
           
            if (chkBuffet.Checked)
            {
                stayInfo += intNights + " entrie(s) to our breakfast buffet\n";
                dblTotal += (intNights * 10);
            }
            if (chkTix.Checked)
            {
                stayInfo += "Two tickets to our movie theater\n";
                dblTotal += 50;
            }
            if (chkGolf.Checked)
            {
                stayInfo += "18 holes of Golf plus a cart\n";
                dblTotal += 80;
            }
            stayInfo += "Total: " + dblTotal.ToString("C");
            MessageBox.Show(stayInfo,
                            "Your Stay",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
        }
    }
}
