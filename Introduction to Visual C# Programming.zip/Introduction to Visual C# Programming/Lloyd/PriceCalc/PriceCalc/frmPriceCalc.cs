﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PriceCalc
{
    public partial class frmPriceCalc : Form
    {
        public frmPriceCalc()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            try
            {
                // inputs
                int intQty = int.Parse(txtQuantity.Text);
                double dblPrice = double.Parse(txtPrice.Text);
                // process
                const double TAX_RATE = .05;
                double dblSubTotal = intQty * dblPrice;
                double dblDiscountPercent = 0;
                double dblDiscountDollars = 0;

                if (intQty >= 30)
                    dblDiscountPercent = .40;
                else if (intQty >= 20)
                    dblDiscountPercent = .25;
                else if (intQty >= 10)
                    dblDiscountPercent = .10;
                else
                    dblDiscountPercent = 0;


                dblDiscountDollars = dblSubTotal * dblDiscountPercent;
                dblSubTotal -= dblDiscountDollars;

                dblSubTotal *= (1 + TAX_RATE);
                // outputs
                txtDiscount.Text = dblDiscountDollars.ToString("C");
                txtTotal.Text = dblSubTotal.ToString("C");
            }
            catch (Exception ex)
            {
                DialogResult result = 
                    MessageBox.Show("Please enter valid numbers.\nWould You like to try again?" ,
                                "Data Entry Error",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Error);

                if (result == DialogResult.No)
                    this.Close();
                else
                {
                    txtQuantity.Clear();
                    txtPrice.Clear();
                    txtQuantity.Focus();
                }
            }
        }
    }
}
