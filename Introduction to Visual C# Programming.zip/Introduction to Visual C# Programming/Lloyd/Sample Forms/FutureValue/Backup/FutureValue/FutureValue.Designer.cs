namespace FutureValue
{
    partial class FutureValue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSavingsQuestion = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtInitialSavings = new System.Windows.Forms.TextBox();
            this.txtAnnualDeposit = new System.Windows.Forms.TextBox();
            this.txtRateOfReturn = new System.Windows.Forms.TextBox();
            this.txtSavingsTerm = new System.Windows.Forms.TextBox();
            this.txtTotalSavings = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblSavingsQuestion
            // 
            this.lblSavingsQuestion.Location = new System.Drawing.Point(26, 18);
            this.lblSavingsQuestion.Name = "lblSavingsQuestion";
            this.lblSavingsQuestion.Size = new System.Drawing.Size(240, 23);
            this.lblSavingsQuestion.TabIndex = 0;
            this.lblSavingsQuestion.Text = "How much will I save?";
            this.lblSavingsQuestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Initial Savings";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Annual Deposit";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(38, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Annual Rate of Return";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(38, 136);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Years to Save";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(38, 162);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Savings Total";
            // 
            // txtInitialSavings
            // 
            this.txtInitialSavings.Location = new System.Drawing.Point(155, 55);
            this.txtInitialSavings.Name = "txtInitialSavings";
            this.txtInitialSavings.Size = new System.Drawing.Size(100, 20);
            this.txtInitialSavings.TabIndex = 6;
            // 
            // txtAnnualDeposit
            // 
            this.txtAnnualDeposit.Location = new System.Drawing.Point(155, 81);
            this.txtAnnualDeposit.Name = "txtAnnualDeposit";
            this.txtAnnualDeposit.Size = new System.Drawing.Size(100, 20);
            this.txtAnnualDeposit.TabIndex = 7;
            // 
            // txtRateOfReturn
            // 
            this.txtRateOfReturn.Location = new System.Drawing.Point(155, 107);
            this.txtRateOfReturn.Name = "txtRateOfReturn";
            this.txtRateOfReturn.Size = new System.Drawing.Size(100, 20);
            this.txtRateOfReturn.TabIndex = 8;
            // 
            // txtSavingsTerm
            // 
            this.txtSavingsTerm.Location = new System.Drawing.Point(155, 133);
            this.txtSavingsTerm.Name = "txtSavingsTerm";
            this.txtSavingsTerm.Size = new System.Drawing.Size(100, 20);
            this.txtSavingsTerm.TabIndex = 9;
            // 
            // txtTotalSavings
            // 
            this.txtTotalSavings.Enabled = false;
            this.txtTotalSavings.Location = new System.Drawing.Point(155, 159);
            this.txtTotalSavings.Name = "txtTotalSavings";
            this.txtTotalSavings.Size = new System.Drawing.Size(100, 20);
            this.txtTotalSavings.TabIndex = 10;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(190, 203);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 11;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(109, 203);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 12;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(28, 203);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 23);
            this.btnCalculate.TabIndex = 13;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // FutureValue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 255);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.txtTotalSavings);
            this.Controls.Add(this.txtSavingsTerm);
            this.Controls.Add(this.txtRateOfReturn);
            this.Controls.Add(this.txtAnnualDeposit);
            this.Controls.Add(this.txtInitialSavings);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblSavingsQuestion);
            this.Name = "FutureValue";
            this.Text = "Savings Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSavingsQuestion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtInitialSavings;
        private System.Windows.Forms.TextBox txtAnnualDeposit;
        private System.Windows.Forms.TextBox txtRateOfReturn;
        private System.Windows.Forms.TextBox txtSavingsTerm;
        private System.Windows.Forms.TextBox txtTotalSavings;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnCalculate;
    }
}

