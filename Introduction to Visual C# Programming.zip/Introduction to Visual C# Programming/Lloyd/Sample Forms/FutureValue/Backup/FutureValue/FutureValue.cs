using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FutureValue
{
    public partial class FutureValue : Form
    {
        public FutureValue()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, System.EventArgs e)
        {
            txtInitialSavings.Text = "";
            txtAnnualDeposit.Text = "";
            txtRateOfReturn.Text = "";
            txtSavingsTerm.Text = "";
            txtTotalSavings.Text = "";

            txtInitialSavings.Focus();
        }

        private void btnClose_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}