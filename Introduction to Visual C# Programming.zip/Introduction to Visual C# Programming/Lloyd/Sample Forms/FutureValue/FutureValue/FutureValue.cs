using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FutureValue
{
    public partial class FutureValue : Form
    {
        public FutureValue()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double dblInitialSavings = double.Parse(txtInitialSavings.Text);
            double dblAnnualDeposit = double.Parse(txtAnnualDeposit.Text);
            double dblRateOfReturn = double.Parse(txtRateOfReturn.Text);
            int intYears = int.Parse(txtSavingsTerm.Text);
            double dblSavings = dblInitialSavings;

            for (int i = 1; i <= intYears; i++)
            {
                dblSavings += dblAnnualDeposit;
                dblSavings *= (1 + dblRateOfReturn);
            }

            txtTotalSavings.Text = dblSavings.ToString("C");
        }

        private void btnClear_Click(object sender, System.EventArgs e)
        {
            txtInitialSavings.Text = "";
            txtAnnualDeposit.Text = "";
            txtRateOfReturn.Text = "";
            txtSavingsTerm.Text = "";
            txtTotalSavings.Text = "";

            txtInitialSavings.Focus();
        }

        private void btnClose_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}