using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Magic8Ball
{
    public partial class Magic8Ball : Form
    {
        public Magic8Ball()
        {
            InitializeComponent();
        }

        // global variable 
        //String[] m_strResponses = new String[8];
        String[] m_strResponses = {"Yes",
                                   "No",
                                   "Maybe",
                                   "For Sure",
                                   "I don't have a clue",
                                   "Heck No",
                                   "50/50 shot",
                                   "It don't look good homey!"};
                


        private void btnAsk_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int intRandom = rnd.Next(8);
            lblAnswer.Text = m_strResponses[intRandom];
        }

        private void btnDisplayAll_Click(object sender, EventArgs e)
        {
            lblDisplayAll.Text = "";
            foreach (String response in m_strResponses)
            {
                lblDisplayAll.Text += response + "\n";
            }
        }
    }
}