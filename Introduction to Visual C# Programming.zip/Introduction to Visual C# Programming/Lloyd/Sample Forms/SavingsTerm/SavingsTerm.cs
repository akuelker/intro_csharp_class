using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SavingsTerm
{
    public partial class SavingsTerm : Form
    {
        public SavingsTerm()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (cboQuestion.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a question");
                return;
            }

            //inputs
            double dblInitialSavings = double.Parse(txtInitialSavings.Text);
            double dblAnnualDeposit = double.Parse(txtAnnualDeposit.Text);
            double dblRateOfReturn = double.Parse(txtRateOfReturn.Text);
            double dblSavings = dblInitialSavings;
            int intYears = 0;

            if (cboQuestion.SelectedIndex == 0 || cboQuestion.SelectedIndex == 1)
            { //while loop to goal
                double dblSavingsGoal = double.Parse(txtSavingsGoal.Text);
                while (dblSavings < dblSavingsGoal)
                {
                    dblSavings += dblAnnualDeposit;
                    dblSavings *= (1 + dblRateOfReturn);
                    intYears++;
                }
                txtSavingsTerm.Text = intYears.ToString();
            }
            else if (cboQuestion.SelectedIndex == 2)
            { // for loop to num of years
                intYears = int.Parse(txtSavingsTerm.Text);
                for (int i = 1; i < intYears; i++)
                {
                    dblSavings += dblAnnualDeposit;
                    dblSavings *= (1 + dblRateOfReturn);
                }
            }
            else
            { // have not selected a question yet
                MessageBox.Show("Select a question!");
            }

            txtTotalSavings.Text = dblSavings.ToString("C");

        }

        private void btnClear_Click(object sender, System.EventArgs e)
        {
            txtInitialSavings.Text = "";
            txtAnnualDeposit.Text = "";
            txtRateOfReturn.Text = "";
            txtSavingsGoal.Text = "";
            txtSavingsTerm.Text = "";
            txtTotalSavings.Text = "";

            txtInitialSavings.Focus();
        }

        private void btnClose_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void cboQuestion_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cboQuestion.SelectedIndex)
            {
                case 0:
                    lblSavingsGoal.Visible = true;
                    txtSavingsGoal.Visible = true;
                    txtSavingsGoal.Text = "1000000";
                    txtSavingsGoal.Enabled = false;
                    txtSavingsTerm.Enabled = false;
                    break;
                case 1:
                    lblSavingsGoal.Visible = true;
                    txtSavingsGoal.Visible = true;
                    txtSavingsGoal.Text = "";
                    txtSavingsGoal.Enabled = true;
                    txtSavingsTerm.Enabled = false;
                    break;
                case 2:
                    lblSavingsGoal.Visible = false;
                    txtSavingsGoal.Visible = false;
                    txtSavingsTerm.Enabled = true;
                    break;
            }
        }
    }
}