using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Ex1_Alignment
{
    public partial class AlignmentForm : Form
    {
        public AlignmentForm()
        {
            InitializeComponent();
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {
            lblAlign.Text = "Left";
            lblAlign.TextAlign = ContentAlignment.MiddleLeft;
            btnLeft.Enabled = false;
            btnCenter.Enabled = true;
            btnRight.Enabled = true;
        }

        private void btnCenter_Click(object sender, EventArgs e)
        {
            lblAlign.Text = "Center";
            lblAlign.TextAlign = ContentAlignment.MiddleCenter;
            btnLeft.Enabled = true;
            btnCenter.Enabled = false;
            btnRight.Enabled = true;
        }

        private void btnRight_Click(object sender, EventArgs e)
        {
            lblAlign.Text = "Right";
            lblAlign.TextAlign = ContentAlignment.MiddleRight;
            btnLeft.Enabled = true;
            btnCenter.Enabled = true;
            btnRight.Enabled = false;
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}