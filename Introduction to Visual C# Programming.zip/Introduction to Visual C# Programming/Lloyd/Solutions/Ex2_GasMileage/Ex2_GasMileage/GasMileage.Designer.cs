namespace Ex2_GasMileage
{
    partial class GasMileage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnMPG = new System.Windows.Forms.Button();
            this.txtStartMiles = new System.Windows.Forms.TextBox();
            this.txtEndMiles = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtGallonsUsed = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMPG = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Odometer Reading\r\n(Start of Trip)\r\n";
            // 
            // btnMPG
            // 
            this.btnMPG.Location = new System.Drawing.Point(94, 190);
            this.btnMPG.Name = "btnMPG";
            this.btnMPG.Size = new System.Drawing.Size(104, 23);
            this.btnMPG.TabIndex = 1;
            this.btnMPG.Text = "Miles Per Gallon";
            this.btnMPG.UseVisualStyleBackColor = true;
            this.btnMPG.Click += new System.EventHandler(this.btnMPG_Click);
            // 
            // txtStartMiles
            // 
            this.txtStartMiles.Location = new System.Drawing.Point(151, 29);
            this.txtStartMiles.Name = "txtStartMiles";
            this.txtStartMiles.Size = new System.Drawing.Size(100, 20);
            this.txtStartMiles.TabIndex = 2;
            // 
            // txtEndMiles
            // 
            this.txtEndMiles.Location = new System.Drawing.Point(151, 69);
            this.txtEndMiles.Name = "txtEndMiles";
            this.txtEndMiles.Size = new System.Drawing.Size(100, 20);
            this.txtEndMiles.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 26);
            this.label2.TabIndex = 3;
            this.label2.Text = "Odometer Reading\r\n(End of Trip)\r\n";
            // 
            // txtGallonsUsed
            // 
            this.txtGallonsUsed.Location = new System.Drawing.Point(151, 107);
            this.txtGallonsUsed.Name = "txtGallonsUsed";
            this.txtGallonsUsed.Size = new System.Drawing.Size(100, 20);
            this.txtGallonsUsed.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Gas Used (Gallons)\r\n";
            // 
            // txtMPG
            // 
            this.txtMPG.Enabled = false;
            this.txtMPG.Location = new System.Drawing.Point(151, 145);
            this.txtMPG.Name = "txtMPG";
            this.txtMPG.Size = new System.Drawing.Size(100, 20);
            this.txtMPG.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Miles Per Gallon\r\n";
            // 
            // GasMileage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 247);
            this.Controls.Add(this.txtMPG);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtGallonsUsed);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtEndMiles);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtStartMiles);
            this.Controls.Add(this.btnMPG);
            this.Controls.Add(this.label1);
            this.Name = "GasMileage";
            this.Text = "Gas Mileage Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnMPG;
        private System.Windows.Forms.TextBox txtStartMiles;
        private System.Windows.Forms.TextBox txtEndMiles;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtGallonsUsed;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMPG;
        private System.Windows.Forms.Label label4;
    }
}

