using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Ex2_GasMileage
{
    public partial class GasMileage : Form
    {
        public GasMileage()
        {
            InitializeComponent();
        }

        private void btnMPG_Click(object sender, EventArgs e)
        {
            int intStartMiles = int.Parse(txtStartMiles.Text);
            int intEndMiles = int.Parse(txtEndMiles.Text);
            double dblGallonsUsed = double.Parse(txtGallonsUsed.Text);
            double dblMPG = (intEndMiles - intStartMiles) / dblGallonsUsed;

            txtMPG.Text = dblMPG.ToString();
        }
    }
}