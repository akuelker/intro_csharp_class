using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Ex2_TempConverter
{
    public partial class TempConverter : Form
    {
        public TempConverter()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            double dblFahr = double.Parse(txtFahr.Text);
            double dblCelsius = 5.0 / 9.0 * (dblFahr - 32);

            txtCelsius.Text = dblCelsius.ToString();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFahr.Text = "";
            txtCelsius.Text = "";
            txtFahr.Focus();
        }
    }
}