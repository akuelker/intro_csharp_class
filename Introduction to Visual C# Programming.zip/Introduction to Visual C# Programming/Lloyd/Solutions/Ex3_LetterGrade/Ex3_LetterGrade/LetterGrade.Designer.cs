namespace Ex3_LetterGrade
{
    partial class LetterGrade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTestScore = new System.Windows.Forms.Label();
            this.txtTestScore = new System.Windows.Forms.TextBox();
            this.btnCalcGrade = new System.Windows.Forms.Button();
            this.txtLetterGrade = new System.Windows.Forms.TextBox();
            this.lblLetterGrade = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTestScore
            // 
            this.lblTestScore.AutoSize = true;
            this.lblTestScore.Location = new System.Drawing.Point(59, 32);
            this.lblTestScore.Name = "lblTestScore";
            this.lblTestScore.Size = new System.Drawing.Size(59, 13);
            this.lblTestScore.TabIndex = 0;
            this.lblTestScore.Text = "Test Score";
            // 
            // txtTestScore
            // 
            this.txtTestScore.Location = new System.Drawing.Point(134, 32);
            this.txtTestScore.Name = "txtTestScore";
            this.txtTestScore.Size = new System.Drawing.Size(100, 20);
            this.txtTestScore.TabIndex = 1;
            // 
            // btnCalcGrade
            // 
            this.btnCalcGrade.Location = new System.Drawing.Point(84, 99);
            this.btnCalcGrade.Name = "btnCalcGrade";
            this.btnCalcGrade.Size = new System.Drawing.Size(125, 23);
            this.btnCalcGrade.TabIndex = 2;
            this.btnCalcGrade.Text = "Calculate Grade";
            this.btnCalcGrade.UseVisualStyleBackColor = true;
            this.btnCalcGrade.Click += new System.EventHandler(this.btnCalcGrade_Click);
            // 
            // txtLetterGrade
            // 
            this.txtLetterGrade.Location = new System.Drawing.Point(134, 58);
            this.txtLetterGrade.Name = "txtLetterGrade";
            this.txtLetterGrade.Size = new System.Drawing.Size(100, 20);
            this.txtLetterGrade.TabIndex = 4;
            // 
            // lblLetterGrade
            // 
            this.lblLetterGrade.AutoSize = true;
            this.lblLetterGrade.Location = new System.Drawing.Point(59, 58);
            this.lblLetterGrade.Name = "lblLetterGrade";
            this.lblLetterGrade.Size = new System.Drawing.Size(66, 13);
            this.lblLetterGrade.TabIndex = 3;
            this.lblLetterGrade.Text = "Letter Grade";
            // 
            // LetterGrade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 164);
            this.Controls.Add(this.txtLetterGrade);
            this.Controls.Add(this.lblLetterGrade);
            this.Controls.Add(this.btnCalcGrade);
            this.Controls.Add(this.txtTestScore);
            this.Controls.Add(this.lblTestScore);
            this.Name = "LetterGrade";
            this.Text = "Grade Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTestScore;
        private System.Windows.Forms.TextBox txtTestScore;
        private System.Windows.Forms.Button btnCalcGrade;
        private System.Windows.Forms.TextBox txtLetterGrade;
        private System.Windows.Forms.Label lblLetterGrade;
    }
}

