using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Ex3_LetterGrade
{
    public partial class LetterGrade : Form
    {
        public LetterGrade()
        {
            InitializeComponent();
        }

        private void btnCalcGrade_Click(object sender, EventArgs e)
        {
            int intScore = int.Parse(txtTestScore.Text);
            string strLetterGrade;

            if (intScore >= 0 && intScore <= 100)
            {
                if (intScore >= 90)
                {
                    strLetterGrade = "A";
                }
                else if (intScore >= 80)
                {
                    strLetterGrade = "B";
                }
                else if (intScore >= 70)
                {
                    strLetterGrade = "C";
                }
                else if (intScore >= 60)
                {
                    strLetterGrade = "D";
                }
                else
                {
                    strLetterGrade = "F";
                }
                txtLetterGrade.Text = strLetterGrade;
            }
            else
            {
                DialogResult response = MessageBox.Show("Please enter a grade between 0 and 100.\n" + "Do you want to try again?", "Entry Error", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                if (response == DialogResult.Yes)
                {
                    txtTestScore.Text = "";
                    txtLetterGrade.Text = "";
                    txtTestScore.Focus();
                }
                else
                {
                    this.Close();
                }
            }
        }
    }
}