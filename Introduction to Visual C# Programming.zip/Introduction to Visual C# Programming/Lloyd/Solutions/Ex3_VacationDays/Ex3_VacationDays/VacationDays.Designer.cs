namespace Ex3_VacationDays
{
    partial class VacationDays
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblYearsOfService = new System.Windows.Forms.Label();
            this.txtYearsOfService = new System.Windows.Forms.TextBox();
            this.btnVacation = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblYearsOfService
            // 
            this.lblYearsOfService.AutoSize = true;
            this.lblYearsOfService.Location = new System.Drawing.Point(70, 29);
            this.lblYearsOfService.Name = "lblYearsOfService";
            this.lblYearsOfService.Size = new System.Drawing.Size(83, 13);
            this.lblYearsOfService.TabIndex = 0;
            this.lblYearsOfService.Text = "Years of service";
            // 
            // txtYearsOfService
            // 
            this.txtYearsOfService.Location = new System.Drawing.Point(159, 29);
            this.txtYearsOfService.Name = "txtYearsOfService";
            this.txtYearsOfService.Size = new System.Drawing.Size(64, 20);
            this.txtYearsOfService.TabIndex = 1;
            // 
            // btnVacation
            // 
            this.btnVacation.Location = new System.Drawing.Point(89, 79);
            this.btnVacation.Name = "btnVacation";
            this.btnVacation.Size = new System.Drawing.Size(114, 23);
            this.btnVacation.TabIndex = 2;
            this.btnVacation.Text = "Calculate Vacation";
            this.btnVacation.UseVisualStyleBackColor = true;
            this.btnVacation.Click += new System.EventHandler(this.btnVacation_Click);
            // 
            // VacationDays
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 146);
            this.Controls.Add(this.btnVacation);
            this.Controls.Add(this.txtYearsOfService);
            this.Controls.Add(this.lblYearsOfService);
            this.Name = "VacationDays";
            this.Text = "Vacation Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblYearsOfService;
        private System.Windows.Forms.TextBox txtYearsOfService;
        private System.Windows.Forms.Button btnVacation;
    }
}

