using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Ex3_VacationDays
{
    public partial class VacationDays : Form
    {
        public VacationDays()
        {
            InitializeComponent();
        }

        private void btnVacation_Click(object sender, EventArgs e)
        {
            int intYears = int.Parse(txtYearsOfService.Text);
            int intVacDays;

            if (intYears < 1)
            {
                intVacDays = 5;
            }
            else if (intYears <= 5)
            {
                intVacDays = 10;
            }
            else if (intYears <= 10)
            {
                intVacDays = 15;
            }
            else
            {
                intVacDays = 20;
            }

            MessageBox.Show("You get " + intVacDays + " vacation days.", "Vacation Days", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}