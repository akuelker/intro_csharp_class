using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Ex3_VotingAge
{
    public partial class VotingAge : Form
    {
        public VotingAge()
        {
            InitializeComponent();
        }

        private void btnVote_Click(object sender, EventArgs e)
        {
            int intAge = int.Parse(txtAge.Text);

            if (intAge >= 18)
            {
                MessageBox.Show("Congratulations! You can vote?", "Voting Results");
            }
            else
            {
                int intWait = 18 - intAge;
                MessageBox.Show("You must wait " + intWait + " years to vote.", "Voting Results");
            }
        }
    }
}