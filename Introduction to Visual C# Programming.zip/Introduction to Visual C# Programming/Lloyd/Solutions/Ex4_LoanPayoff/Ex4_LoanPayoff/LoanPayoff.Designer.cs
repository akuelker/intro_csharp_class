namespace Ex4_LoanPayoff
{
    partial class LoanPayoff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPayment = new System.Windows.Forms.TextBox();
            this.lblPayment = new System.Windows.Forms.Label();
            this.btnCalcTerm = new System.Windows.Forms.Button();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.lblBalance = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtPayment
            // 
            this.txtPayment.Location = new System.Drawing.Point(153, 56);
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.Size = new System.Drawing.Size(100, 20);
            this.txtPayment.TabIndex = 9;
            // 
            // lblPayment
            // 
            this.lblPayment.AutoSize = true;
            this.lblPayment.Location = new System.Drawing.Point(42, 56);
            this.lblPayment.Name = "lblPayment";
            this.lblPayment.Size = new System.Drawing.Size(89, 13);
            this.lblPayment.TabIndex = 8;
            this.lblPayment.Text = "Periodic Payment";
            // 
            // btnCalcTerm
            // 
            this.btnCalcTerm.Location = new System.Drawing.Point(64, 92);
            this.btnCalcTerm.Name = "btnCalcTerm";
            this.btnCalcTerm.Size = new System.Drawing.Size(168, 23);
            this.btnCalcTerm.TabIndex = 7;
            this.btnCalcTerm.Text = "Calculate Number of Payments";
            this.btnCalcTerm.UseVisualStyleBackColor = true;
            this.btnCalcTerm.Click += new System.EventHandler(this.btnCalcTerm_Click);
            // 
            // txtBalance
            // 
            this.txtBalance.Location = new System.Drawing.Point(153, 26);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.Size = new System.Drawing.Size(100, 20);
            this.txtBalance.TabIndex = 6;
            // 
            // lblBalance
            // 
            this.lblBalance.AutoSize = true;
            this.lblBalance.Location = new System.Drawing.Point(42, 26);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(73, 13);
            this.lblBalance.TabIndex = 5;
            this.lblBalance.Text = "Initial Balance";
            // 
            // LoanPayoff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 158);
            this.Controls.Add(this.txtPayment);
            this.Controls.Add(this.lblPayment);
            this.Controls.Add(this.btnCalcTerm);
            this.Controls.Add(this.txtBalance);
            this.Controls.Add(this.lblBalance);
            this.Name = "LoanPayoff";
            this.Text = "Payoff Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPayment;
        private System.Windows.Forms.Label lblPayment;
        private System.Windows.Forms.Button btnCalcTerm;
        private System.Windows.Forms.TextBox txtBalance;
        private System.Windows.Forms.Label lblBalance;
    }
}

