using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Ex4_LoanPayoff
{
    public partial class LoanPayoff : Form
    {
        public LoanPayoff()
        {
            InitializeComponent();
        }

        private void btnCalcTerm_Click(object sender, EventArgs e)
        {
            double dblBalance = double.Parse(txtBalance.Text);
            double dblPayment = double.Parse(txtPayment.Text);

            int intNumPayments = 0;

            while (dblBalance > 0)
            {
                dblBalance -= dblPayment;
                intNumPayments++;
            }
            MessageBox.Show("You can pay off the loan in " + intNumPayments + " payments.", "Number of Payments");

        }
    }
}