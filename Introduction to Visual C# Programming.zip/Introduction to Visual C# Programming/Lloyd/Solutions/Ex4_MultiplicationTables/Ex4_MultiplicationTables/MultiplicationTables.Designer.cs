namespace Ex4_MultiplicationTables
{
    partial class MultiplicationTables
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMultTable = new System.Windows.Forms.Label();
            this.btnPrintTable = new System.Windows.Forms.Button();
            this.lblInteger = new System.Windows.Forms.Label();
            this.txtInteger = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblMultTable
            // 
            this.lblMultTable.Location = new System.Drawing.Point(28, 93);
            this.lblMultTable.Name = "lblMultTable";
            this.lblMultTable.Size = new System.Drawing.Size(156, 170);
            this.lblMultTable.TabIndex = 0;
            // 
            // btnPrintTable
            // 
            this.btnPrintTable.Location = new System.Drawing.Point(22, 53);
            this.btnPrintTable.Name = "btnPrintTable";
            this.btnPrintTable.Size = new System.Drawing.Size(165, 23);
            this.btnPrintTable.TabIndex = 1;
            this.btnPrintTable.Text = "Print Multiplication Table";
            this.btnPrintTable.UseVisualStyleBackColor = true;
            this.btnPrintTable.Click += new System.EventHandler(this.btnPrintTable_Click);
            // 
            // lblInteger
            // 
            this.lblInteger.AutoSize = true;
            this.lblInteger.Location = new System.Drawing.Point(25, 20);
            this.lblInteger.Name = "lblInteger";
            this.lblInteger.Size = new System.Drawing.Size(83, 13);
            this.lblInteger.TabIndex = 2;
            this.lblInteger.Text = "Enter an Integer";
            // 
            // txtInteger
            // 
            this.txtInteger.Location = new System.Drawing.Point(125, 20);
            this.txtInteger.Name = "txtInteger";
            this.txtInteger.Size = new System.Drawing.Size(59, 20);
            this.txtInteger.TabIndex = 3;
            // 
            // MultiplicationTables
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(212, 286);
            this.Controls.Add(this.txtInteger);
            this.Controls.Add(this.lblInteger);
            this.Controls.Add(this.btnPrintTable);
            this.Controls.Add(this.lblMultTable);
            this.Name = "MultiplicationTables";
            this.Text = "Multiplication Tables";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMultTable;
        private System.Windows.Forms.Button btnPrintTable;
        private System.Windows.Forms.Label lblInteger;
        private System.Windows.Forms.TextBox txtInteger;
    }
}

