using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Ex4_MultiplicationTables
{
    public partial class MultiplicationTables : Form
    {
        public MultiplicationTables()
        {
            InitializeComponent();
        }

        private void btnPrintTable_Click(object sender, EventArgs e)
        {
            int intNumEntry = int.Parse(txtInteger.Text);
            lblMultTable.Text = "";

            for (int i = 1; i <= 12; i++)
            {
                lblMultTable.Text += intNumEntry + " x " + i + " = " + (intNumEntry * i) + "\n";
            }
        }
    }
}