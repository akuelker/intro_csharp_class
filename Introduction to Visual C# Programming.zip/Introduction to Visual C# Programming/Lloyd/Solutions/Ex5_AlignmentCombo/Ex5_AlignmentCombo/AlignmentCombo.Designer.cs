namespace Ex5_AlignmentCombo
{
    partial class AlignmentCombo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAlign = new System.Windows.Forms.Label();
            this.lblComboLabel = new System.Windows.Forms.Label();
            this.cboAlignment = new System.Windows.Forms.ComboBox();
            this.btnQuit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblAlign
            // 
            this.lblAlign.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAlign.Location = new System.Drawing.Point(29, 36);
            this.lblAlign.Name = "lblAlign";
            this.lblAlign.Size = new System.Drawing.Size(237, 23);
            this.lblAlign.TabIndex = 0;
            // 
            // lblComboLabel
            // 
            this.lblComboLabel.AutoSize = true;
            this.lblComboLabel.Location = new System.Drawing.Point(29, 78);
            this.lblComboLabel.Name = "lblComboLabel";
            this.lblComboLabel.Size = new System.Drawing.Size(106, 13);
            this.lblComboLabel.TabIndex = 1;
            this.lblComboLabel.Text = "Select the alignment:";
            // 
            // cboAlignment
            // 
            this.cboAlignment.FormattingEnabled = true;
            this.cboAlignment.Items.AddRange(new object[] {
            "Left",
            "Center",
            "Right"});
            this.cboAlignment.Location = new System.Drawing.Point(145, 78);
            this.cboAlignment.Name = "cboAlignment";
            this.cboAlignment.Size = new System.Drawing.Size(121, 21);
            this.cboAlignment.TabIndex = 2;
            this.cboAlignment.SelectedIndexChanged += new System.EventHandler(this.cboAlignment_SelectedIndexChanged);
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(191, 121);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(75, 23);
            this.btnQuit.TabIndex = 3;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // AlignmentCombo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 174);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.cboAlignment);
            this.Controls.Add(this.lblComboLabel);
            this.Controls.Add(this.lblAlign);
            this.Name = "AlignmentCombo";
            this.Text = "Alignment";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAlign;
        private System.Windows.Forms.Label lblComboLabel;
        private System.Windows.Forms.ComboBox cboAlignment;
        private System.Windows.Forms.Button btnQuit;
    }
}

