using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Ex5_AlignmentCombo
{
    public partial class AlignmentCombo : Form
    {
        public AlignmentCombo()
        {
            InitializeComponent();
        }

        private void cboAlignment_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblAlign.Text = cboAlignment.Text;

            switch (cboAlignment.Text)
            {
                case "Left":
                    lblAlign.TextAlign = ContentAlignment.MiddleLeft;
                    break;
                case "Center":
                    lblAlign.TextAlign = ContentAlignment.MiddleCenter;
                    break;
                case "Right":
                    lblAlign.TextAlign = ContentAlignment.MiddleRight;
                    break;
            }
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }
    }
}