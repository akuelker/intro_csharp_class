namespace Ex5_TempConverterCombo
{
    partial class TempCombo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConvert = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblConvertedTemp = new System.Windows.Forms.Label();
            this.lblUnits = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTempToConvert = new System.Windows.Forms.TextBox();
            this.cboUnits = new System.Windows.Forms.ComboBox();
            this.lblTempToConvert = new System.Windows.Forms.Label();
            this.txtConvertedTemp = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnConvert
            // 
            this.btnConvert.Location = new System.Drawing.Point(111, 127);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(75, 23);
            this.btnConvert.TabIndex = 0;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(246, 127);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 1;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblConvertedTemp
            // 
            this.lblConvertedTemp.AutoSize = true;
            this.lblConvertedTemp.Location = new System.Drawing.Point(22, 65);
            this.lblConvertedTemp.Name = "lblConvertedTemp";
            this.lblConvertedTemp.Size = new System.Drawing.Size(89, 13);
            this.lblConvertedTemp.TabIndex = 2;
            this.lblConvertedTemp.Text = "Converted Temp:";
            // 
            // lblUnits
            // 
            this.lblUnits.AutoSize = true;
            this.lblUnits.Location = new System.Drawing.Point(253, 65);
            this.lblUnits.Name = "lblUnits";
            this.lblUnits.Size = new System.Drawing.Size(81, 13);
            this.lblUnits.TabIndex = 3;
            this.lblUnits.Text = "degrees Celsius";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(134, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 4;
            // 
            // txtTempToConvert
            // 
            this.txtTempToConvert.Location = new System.Drawing.Point(137, 29);
            this.txtTempToConvert.Name = "txtTempToConvert";
            this.txtTempToConvert.Size = new System.Drawing.Size(100, 20);
            this.txtTempToConvert.TabIndex = 6;
            // 
            // cboUnits
            // 
            this.cboUnits.FormattingEnabled = true;
            this.cboUnits.Items.AddRange(new object[] {
            "degrees Fahrenheit",
            "degrees Celsius"});
            this.cboUnits.Location = new System.Drawing.Point(256, 29);
            this.cboUnits.Name = "cboUnits";
            this.cboUnits.Size = new System.Drawing.Size(145, 21);
            this.cboUnits.TabIndex = 7;
            // 
            // lblTempToConvert
            // 
            this.lblTempToConvert.AutoSize = true;
            this.lblTempToConvert.Location = new System.Drawing.Point(22, 29);
            this.lblTempToConvert.Name = "lblTempToConvert";
            this.lblTempToConvert.Size = new System.Drawing.Size(89, 13);
            this.lblTempToConvert.TabIndex = 8;
            this.lblTempToConvert.Text = "Temp to Convert:";
            // 
            // txtConvertedTemp
            // 
            this.txtConvertedTemp.Enabled = false;
            this.txtConvertedTemp.Location = new System.Drawing.Point(137, 65);
            this.txtConvertedTemp.Name = "txtConvertedTemp";
            this.txtConvertedTemp.Size = new System.Drawing.Size(100, 20);
            this.txtConvertedTemp.TabIndex = 9;
            // 
            // TempCombo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(433, 170);
            this.Controls.Add(this.txtConvertedTemp);
            this.Controls.Add(this.lblTempToConvert);
            this.Controls.Add(this.cboUnits);
            this.Controls.Add(this.txtTempToConvert);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblUnits);
            this.Controls.Add(this.lblConvertedTemp);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnConvert);
            this.Name = "TempCombo";
            this.Text = "Temp Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblConvertedTemp;
        private System.Windows.Forms.Label lblUnits;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTempToConvert;
        private System.Windows.Forms.ComboBox cboUnits;
        private System.Windows.Forms.Label lblTempToConvert;
        private System.Windows.Forms.TextBox txtConvertedTemp;
    }
}

