using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Ex5_TempConverterCombo
{
    public partial class TempCombo : Form
    {
        public TempCombo()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            double dblTempToConvert = double.Parse(txtTempToConvert.Text);
            double dblConvertedTemp = 0;

            switch (cboUnits.Text)
            {
                case "degrees Celsius":
                    dblConvertedTemp = 9.0 / 5.0 * dblTempToConvert + 32;
                    lblUnits.Text = "degrees Fahrenheit";
                    break;

                case "degrees Fahrenheit":
                    dblConvertedTemp = 5.0 / 9.0 * (dblTempToConvert - 32);
                    lblUnits.Text = "degrees Celsius";
                    break;
            }

            txtConvertedTemp.Text = dblConvertedTemp.ToString(); 

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtTempToConvert.Text = "";
            txtConvertedTemp.Text = "";
            lblUnits.Text = "";
            txtTempToConvert.Focus(); 
        }
    }
}