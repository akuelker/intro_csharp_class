namespace Ex6_Alignment
{
    partial class Alignment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAlign = new System.Windows.Forms.Label();
            this.radRight = new System.Windows.Forms.RadioButton();
            this.radCenter = new System.Windows.Forms.RadioButton();
            this.radLeft = new System.Windows.Forms.RadioButton();
            this.btnQuit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblAlign
            // 
            this.lblAlign.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAlign.Location = new System.Drawing.Point(25, 31);
            this.lblAlign.Name = "lblAlign";
            this.lblAlign.Size = new System.Drawing.Size(242, 23);
            this.lblAlign.TabIndex = 0;
            this.lblAlign.Text = "Left";
            // 
            // radRight
            // 
            this.radRight.AutoSize = true;
            this.radRight.Location = new System.Drawing.Point(192, 85);
            this.radRight.Name = "radRight";
            this.radRight.Size = new System.Drawing.Size(50, 17);
            this.radRight.TabIndex = 1;
            this.radRight.Text = "Right";
            this.radRight.UseVisualStyleBackColor = true;
            this.radRight.Click += new System.EventHandler(this.radRight_Click);
            // 
            // radCenter
            // 
            this.radCenter.AutoSize = true;
            this.radCenter.Location = new System.Drawing.Point(116, 85);
            this.radCenter.Name = "radCenter";
            this.radCenter.Size = new System.Drawing.Size(56, 17);
            this.radCenter.TabIndex = 2;
            this.radCenter.Text = "Center";
            this.radCenter.UseVisualStyleBackColor = true;
            this.radCenter.Click += new System.EventHandler(this.radCenter_Click);
            // 
            // radLeft
            // 
            this.radLeft.AutoSize = true;
            this.radLeft.Checked = true;
            this.radLeft.Location = new System.Drawing.Point(53, 85);
            this.radLeft.Name = "radLeft";
            this.radLeft.Size = new System.Drawing.Size(43, 17);
            this.radLeft.TabIndex = 3;
            this.radLeft.TabStop = true;
            this.radLeft.Text = "Left";
            this.radLeft.UseVisualStyleBackColor = true;
            this.radLeft.Click += new System.EventHandler(this.radLeft_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(192, 124);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(75, 23);
            this.btnQuit.TabIndex = 4;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // Alignment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 181);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.radLeft);
            this.Controls.Add(this.radCenter);
            this.Controls.Add(this.radRight);
            this.Controls.Add(this.lblAlign);
            this.Name = "Alignment";
            this.Text = "Alignment";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAlign;
        private System.Windows.Forms.RadioButton radRight;
        private System.Windows.Forms.RadioButton radCenter;
        private System.Windows.Forms.RadioButton radLeft;
        private System.Windows.Forms.Button btnQuit;
    }
}

