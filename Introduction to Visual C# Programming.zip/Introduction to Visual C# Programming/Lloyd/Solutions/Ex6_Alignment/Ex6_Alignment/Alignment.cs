using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Ex6_Alignment
{
    public partial class Alignment : Form
    {
        public Alignment()
        {
            InitializeComponent();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Close(); 

        }

        private void radLeft_Click(object sender, EventArgs e)
        {
            lblAlign.TextAlign = ContentAlignment.MiddleLeft;
            lblAlign.Text = "Left"; 
        }

        private void radCenter_Click(object sender, EventArgs e)
        {
            lblAlign.TextAlign = ContentAlignment.MiddleCenter;
            lblAlign.Text = "Center"; 
        }

        private void radRight_Click(object sender, EventArgs e)
        {
            lblAlign.TextAlign = ContentAlignment.MiddleRight;
            lblAlign.Text = "Right"; 
        }
    }
}