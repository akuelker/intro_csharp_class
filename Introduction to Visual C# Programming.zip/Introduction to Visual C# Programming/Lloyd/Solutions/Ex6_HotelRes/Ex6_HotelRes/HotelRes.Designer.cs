namespace Ex6_HotelRes
{
    partial class HotelRes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpQuality = new System.Windows.Forms.GroupBox();
            this.radLuxury = new System.Windows.Forms.RadioButton();
            this.radStandard = new System.Windows.Forms.RadioButton();
            this.radEconomy = new System.Windows.Forms.RadioButton();
            this.cmbNights = new System.Windows.Forms.ComboBox();
            this.grpExtras = new System.Windows.Forms.GroupBox();
            this.chkGolf = new System.Windows.Forms.CheckBox();
            this.chkTheater = new System.Windows.Forms.CheckBox();
            this.chkBreakfast = new System.Windows.Forms.CheckBox();
            this.chkSpa = new System.Windows.Forms.CheckBox();
            this.btnGetPrice = new System.Windows.Forms.Button();
            this.lblTotalLabel = new System.Windows.Forms.Label();
            this.lblTotalPrice = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grpQuality.SuspendLayout();
            this.grpExtras.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpQuality
            // 
            this.grpQuality.Controls.Add(this.radLuxury);
            this.grpQuality.Controls.Add(this.radStandard);
            this.grpQuality.Controls.Add(this.radEconomy);
            this.grpQuality.Location = new System.Drawing.Point(12, 12);
            this.grpQuality.Name = "grpQuality";
            this.grpQuality.Size = new System.Drawing.Size(200, 117);
            this.grpQuality.TabIndex = 0;
            this.grpQuality.TabStop = false;
            this.grpQuality.Text = "Hotel Quality";
            // 
            // radLuxury
            // 
            this.radLuxury.AutoSize = true;
            this.radLuxury.Location = new System.Drawing.Point(17, 82);
            this.radLuxury.Name = "radLuxury";
            this.radLuxury.Size = new System.Drawing.Size(133, 17);
            this.radLuxury.TabIndex = 2;
            this.radLuxury.TabStop = true;
            this.radLuxury.Text = "Luxury ($150 per night)";
            this.radLuxury.UseVisualStyleBackColor = true;
            // 
            // radStandard
            // 
            this.radStandard.AutoSize = true;
            this.radStandard.Location = new System.Drawing.Point(17, 49);
            this.radStandard.Name = "radStandard";
            this.radStandard.Size = new System.Drawing.Size(145, 17);
            this.radStandard.TabIndex = 1;
            this.radStandard.TabStop = true;
            this.radStandard.Text = "Standard ($100 per night)";
            this.radStandard.UseVisualStyleBackColor = true;
            // 
            // radEconomy
            // 
            this.radEconomy.AutoSize = true;
            this.radEconomy.Location = new System.Drawing.Point(17, 19);
            this.radEconomy.Name = "radEconomy";
            this.radEconomy.Size = new System.Drawing.Size(140, 17);
            this.radEconomy.TabIndex = 0;
            this.radEconomy.TabStop = true;
            this.radEconomy.Text = "Economy ($50 per night)";
            this.radEconomy.UseVisualStyleBackColor = true;
            // 
            // cmbNights
            // 
            this.cmbNights.FormattingEnabled = true;
            this.cmbNights.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbNights.Location = new System.Drawing.Point(218, 57);
            this.cmbNights.Name = "cmbNights";
            this.cmbNights.Size = new System.Drawing.Size(85, 21);
            this.cmbNights.TabIndex = 1;
            // 
            // grpExtras
            // 
            this.grpExtras.Controls.Add(this.chkGolf);
            this.grpExtras.Controls.Add(this.chkTheater);
            this.grpExtras.Controls.Add(this.chkBreakfast);
            this.grpExtras.Controls.Add(this.chkSpa);
            this.grpExtras.Location = new System.Drawing.Point(12, 135);
            this.grpExtras.Name = "grpExtras";
            this.grpExtras.Size = new System.Drawing.Size(291, 119);
            this.grpExtras.TabIndex = 3;
            this.grpExtras.TabStop = false;
            this.grpExtras.Text = "Extra Options";
            // 
            // chkGolf
            // 
            this.chkGolf.AutoSize = true;
            this.chkGolf.Location = new System.Drawing.Point(17, 90);
            this.chkGolf.Name = "chkGolf";
            this.chkGolf.Size = new System.Drawing.Size(78, 17);
            this.chkGolf.TabIndex = 3;
            this.chkGolf.Text = "Golf (+$80)";
            this.chkGolf.UseVisualStyleBackColor = true;
            // 
            // chkTheater
            // 
            this.chkTheater.AutoSize = true;
            this.chkTheater.Location = new System.Drawing.Point(17, 67);
            this.chkTheater.Name = "chkTheater";
            this.chkTheater.Size = new System.Drawing.Size(134, 17);
            this.chkTheater.TabIndex = 2;
            this.chkTheater.Text = "Theater Tickets (+$50)";
            this.chkTheater.UseVisualStyleBackColor = true;
            // 
            // chkBreakfast
            // 
            this.chkBreakfast.AutoSize = true;
            this.chkBreakfast.Location = new System.Drawing.Point(17, 44);
            this.chkBreakfast.Name = "chkBreakfast";
            this.chkBreakfast.Size = new System.Drawing.Size(179, 17);
            this.chkBreakfast.TabIndex = 1;
            this.chkBreakfast.Text = "Breakfast Buffet (+$10 per night)";
            this.chkBreakfast.UseVisualStyleBackColor = true;
            // 
            // chkSpa
            // 
            this.chkSpa.AutoSize = true;
            this.chkSpa.Location = new System.Drawing.Point(17, 21);
            this.chkSpa.Name = "chkSpa";
            this.chkSpa.Size = new System.Drawing.Size(127, 17);
            this.chkSpa.TabIndex = 0;
            this.chkSpa.Text = "Spa Voucher (+$250)";
            this.chkSpa.UseVisualStyleBackColor = true;
            // 
            // btnGetPrice
            // 
            this.btnGetPrice.Location = new System.Drawing.Point(130, 260);
            this.btnGetPrice.Name = "btnGetPrice";
            this.btnGetPrice.Size = new System.Drawing.Size(75, 23);
            this.btnGetPrice.TabIndex = 4;
            this.btnGetPrice.Text = "Get Price";
            this.btnGetPrice.UseVisualStyleBackColor = true;
            this.btnGetPrice.Click += new System.EventHandler(this.btnGetPrice_Click);
            // 
            // lblTotalLabel
            // 
            this.lblTotalLabel.AutoSize = true;
            this.lblTotalLabel.Location = new System.Drawing.Point(79, 287);
            this.lblTotalLabel.Name = "lblTotalLabel";
            this.lblTotalLabel.Size = new System.Drawing.Size(58, 13);
            this.lblTotalLabel.TabIndex = 5;
            this.lblTotalLabel.Text = "Total Price";
            // 
            // lblTotalPrice
            // 
            this.lblTotalPrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalPrice.Location = new System.Drawing.Point(155, 286);
            this.lblTotalPrice.Name = "lblTotalPrice";
            this.lblTotalPrice.Size = new System.Drawing.Size(100, 23);
            this.lblTotalPrice.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(218, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Number of Nights";
            // 
            // HotelRes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 324);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblTotalPrice);
            this.Controls.Add(this.lblTotalLabel);
            this.Controls.Add(this.btnGetPrice);
            this.Controls.Add(this.grpExtras);
            this.Controls.Add(this.cmbNights);
            this.Controls.Add(this.grpQuality);
            this.Name = "HotelRes";
            this.Text = "Hotel Reservation Form";
            this.grpQuality.ResumeLayout(false);
            this.grpQuality.PerformLayout();
            this.grpExtras.ResumeLayout(false);
            this.grpExtras.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpQuality;
        private System.Windows.Forms.RadioButton radLuxury;
        private System.Windows.Forms.RadioButton radStandard;
        private System.Windows.Forms.RadioButton radEconomy;
        private System.Windows.Forms.ComboBox cmbNights;
        private System.Windows.Forms.GroupBox grpExtras;
        private System.Windows.Forms.CheckBox chkGolf;
        private System.Windows.Forms.CheckBox chkTheater;
        private System.Windows.Forms.CheckBox chkBreakfast;
        private System.Windows.Forms.CheckBox chkSpa;
        private System.Windows.Forms.Button btnGetPrice;
        private System.Windows.Forms.Label lblTotalLabel;
        private System.Windows.Forms.Label lblTotalPrice;
        private System.Windows.Forms.Label label1;
    }
}

