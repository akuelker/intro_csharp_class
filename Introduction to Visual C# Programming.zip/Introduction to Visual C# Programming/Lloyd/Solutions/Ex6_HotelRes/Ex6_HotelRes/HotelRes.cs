using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Ex6_HotelRes
{
    public partial class HotelRes : Form
    {
        public HotelRes()
        {
            InitializeComponent();
        }

        private void btnGetPrice_Click(object sender, EventArgs e)
        {
            int intNights = int.Parse(cmbNights.Text);
            int intTotalPrice = 0;

            if (radEconomy.Checked)
            {
                intTotalPrice = intNights * 50;
            }
            else if (radStandard.Checked)
            {
                intTotalPrice = intNights * 100;
            }
            else if (radLuxury.Checked)
            {
                intTotalPrice = intNights * 150;
            }

            if (chkSpa.Checked)
            {
                intTotalPrice += 250;
            }

            if (chkBreakfast.Checked)
            {
                intTotalPrice += (intNights * 10);
            }

            if (chkTheater.Checked)
            {
                intTotalPrice += 50;
            }

            if (chkGolf.Checked)
            {
                intTotalPrice += 80;
            }

            lblTotalPrice.Text = intTotalPrice.ToString("C");  


        }
    }
}