﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WelcomeApp
{
    public partial class frmWelcome : Form
    {
        public frmWelcome()
        {
            InitializeComponent();
        }

        private void btnShowMessage_Click(object sender, EventArgs e)
        {
            //comment
            String strName = txtUserName.Text; // comment 2
            txtUserName.Clear();
            lblMessage.Text = "Welcome to C#, "  + strName;
            btnShowMessage.Enabled = false;
            btnClearMessage.Enabled = true;
          
        }

        private void btnClearMessage_Click(object sender, EventArgs e)
        {
            lblMessage.Text = "";
            btnShowMessage.Enabled = true;
            btnClearMessage.Enabled = false;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }


    }
}
