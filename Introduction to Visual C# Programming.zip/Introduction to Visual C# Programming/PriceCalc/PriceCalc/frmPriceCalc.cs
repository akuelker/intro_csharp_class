﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PriceCalc
{
    public partial class frmPriceCalc : Form
    {
        public frmPriceCalc()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            // inputs
            int intQty = int.Parse(txtQuantity.Text);
            double dblPrice = double.Parse(txtPrice.Text);
            // process
            const double TAX_RATE = .05;
            double dblSubTotal = intQty * dblPrice;
            dblSubTotal *= (1 + TAX_RATE);
            // outputs
            txtTotal.Text = dblSubTotal.ToString("C");
        }
    }
}
