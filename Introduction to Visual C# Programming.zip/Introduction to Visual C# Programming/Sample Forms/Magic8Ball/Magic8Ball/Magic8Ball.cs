using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Magic8Ball
{
    public partial class Magic8Ball : Form
    {
        public Magic8Ball()
        {
            InitializeComponent();
        }

        //declare global/class variable here
        //upper case string has methods associated, where lowercase is primitive
        //can't assign here, not a place for code

       // String[] m_strResponses = new String[8]; //8 number of elements, index goes 0-7; new is a call to constructor to create new array of strings with 8 elements
        String[] m_strResponses = {   "Yes",
                                      "No",
                                      "Maybe",
                                      "For Sure",
                                      "I don't have a clue",
                                      "Whatever",
                                      "Possibilities are good",
                                      "Not looking good"};

        //it knows how many based on the value list. loaded up and ready to go.


        private void btnAsk_Click(object sender, EventArgs e)
        { //generate random number between 0 and 7 p 94

            Random rnd = new Random();
            int intRandom = rnd.Next(8); //set random number to hold top value. VB might try to round up so will have to force it to round down
            lblAnswer.Text = m_strResponses[intRandom]; //everytime button pressed, gives new number between 0 and 7
        }

        private void btnDisplayAll_Click(object sender, EventArgs e)
        {
            lblDisplayAll.Text = "";
            foreach (String response in m_strResponses) //loop and grab one each time
            {
                lblDisplayAll.Text += response + "\n";
            }
        }
    }
}