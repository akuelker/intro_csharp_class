using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Millionaire
{
    public partial class Millionaire : Form
    {
        public Millionaire()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            //inputs

            double dblInitialSavings = double.Parse(txtInitialSavings.Text);
            double dblAnnualDeposit = double.Parse(txtAnnualDeposit.Text);
            double dblRateOfReturn = double.Parse(txtRateOfReturn.Text);

            //ctrl +J to get intellisense to start back up if in middle of something. not necessary for VB

            //process

            double dblSavings = dblInitialSavings;
            int intYears = 0; //each pass thru loop will add one for a year. common for a while loop.
            while (dblSavings < 1000000)
            {
                dblSavings += dblAnnualDeposit;
                dblSavings *= (1 + dblRateOfReturn);
                    intYears++;  //exit strategy
            }
            //outputs

            txtSavingsTerm.Text = intYears.ToString();
            txtTotalSavings.Text = dblSavings.ToString("C");

        }

        private void btnClear_Click(object sender, System.EventArgs e)
        {
            txtInitialSavings.Text = "";
            txtAnnualDeposit.Text = "";
            txtRateOfReturn.Text = "";
            txtSavingsTerm.Text = "";
            txtTotalSavings.Text = "";

            txtInitialSavings.Focus();
        }

        private void btnClose_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}