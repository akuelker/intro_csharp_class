using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SavingsTerm
{
    public partial class SavingsTerm : Form
    {
        public SavingsTerm()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (cboQuestion.SelectedIndex == -1)
            {
                MessageBox.Show("Please Select a Question!");
                return;
            }

            //inputs

            double dblInitialSavings = double.Parse(txtInitialSavings.Text);
            double dblAnnualDeposit = double.Parse(txtAnnualDeposit.Text);
            double dblRateOfReturn = double.Parse(txtRateOfReturn.Text);
            double dblSavings = dblInitialSavings;
            int intYears = 0;

            

         if (cboQuestion.SelectedIndex == 0 || cboQuestion.SelectedIndex == 1)
            { //while loop to goal

                double dblSavingsGoal = double.Parse(txtSavingsGoal.Text);
                while (dblSavings < dblSavingsGoal)
                {
                    dblSavingsGoal += dblAnnualDeposit;
                    dblSavings *= (1 + dblRateOfReturn);
                    intYears++;
                }

                txtSavingsTerm.Text = intYears.ToString();
            }

            else if (cboQuestion.SelectedIndex == 2)
            { //for loop to num of years

                double dblSavingsGoal = double.Parse(txtSavingsGoal.Text);
                intYears = int.Parse(txtSavingsTerm.Text);
                for (int i = 1; i < intYears; i++)
                {
                    dblSavingsGoal += dblAnnualDeposit;
                    dblSavings *= (1 + dblRateOfReturn);

                }
            }


            txtTotalSavings.Text = dblSavings.ToString("C");

        }

     

            //process - do loop

      /*      double dblSavings = dblInitialSavings;
            int intYears = 0;
            do
            {
                dblSavings += dblAnnualDeposit;
                dblSavings *= (1 + dblRateOfReturn);
                intYears++;
            } while (dblSavings < dblSavingsGoal); //moves to end of curly braces. Loops at least once even if it doesn't need to, because logic is AFTER loop. Fall through logic.
       */     



                        //process - BETTER, while loop

       

        private void btnClear_Click(object sender, System.EventArgs e)
        {
            txtInitialSavings.Text = "";
            txtAnnualDeposit.Text = "";
            txtRateOfReturn.Text = "";
            txtSavingsGoal.Text = "";
            txtSavingsTerm.Text = "";
            txtTotalSavings.Text = "";

            txtInitialSavings.Focus();
        }

        private void btnClose_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }

        private void cboQuestion_SelectedIndexChanged(object sender, EventArgs e)
        {

            switch (cboQuestion.SelectedIndex)
            {
                case 0:
                //case 61: stack to be case 0 or case 61
                lblSavingsGoal.Visible = true;
                txtSavingsGoal.Visible = true;
                txtSavingsGoal.Text = "1000000";
                txtSavingsGoal.Enabled = false;
                txtSavingsTerm.Enabled = false;

                    break;

                case 1:
                lblSavingsGoal.Visible = true;
                txtSavingsGoal.Visible = true;
                txtSavingsGoal.Text = "";
                txtSavingsGoal.Enabled = true;
                txtSavingsTerm.Enabled = false;

                    break;


                case 2:
                lblSavingsGoal.Visible = false;
                txtSavingsGoal.Visible = false;
                txtSavingsTerm.Enabled = true;

                    break;
            }
            
          //  default: catch all for if none of the cases are met
           // break;

        }

        private void SavingsTerm_Load(object sender, EventArgs e)
        {

        }
    }
}